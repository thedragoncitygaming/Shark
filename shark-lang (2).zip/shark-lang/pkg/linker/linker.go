package linker

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type Linker struct {
	llcPath string
	lldPath string
	verbose bool
}

func New(verbose bool) (*Linker, error) {
	llcPath, err := findTool("llc")
	if err != nil {
		return nil, fmt.Errorf("llc not found: %w (install LLVM)", err)
	}

	lldPath, err := findTool("ld.lld")
	if err != nil {
		return nil, fmt.Errorf("ld.lld not found: %w (install lld)", err)
	}

	return &Linker{
		llcPath: llcPath,
		lldPath: lldPath,
		verbose: verbose,
	}, nil
}

func findTool(name string) (string, error) {
	path, err := exec.LookPath(name)
	if err != nil {
		suffixes := []string{"-17", "-16", "-15", "-14"}
		for _, suffix := range suffixes {
			altPath, altErr := exec.LookPath(name + suffix)
			if altErr == nil {
				return altPath, nil
			}
		}
		return "", fmt.Errorf("%s not found in PATH", name)
	}
	return path, nil
}

func (l *Linker) CompileIR(irCode string, outputPath string) error {
	tmpDir, err := os.MkdirTemp("", "shark-build-*")
	if err != nil {
		return fmt.Errorf("failed to create temp dir: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	llFile := filepath.Join(tmpDir, "output.ll")
	objFile := filepath.Join(tmpDir, "output.o")

	err = os.WriteFile(llFile, []byte(irCode), 0644)
	if err != nil {
		return fmt.Errorf("failed to write IR file: %w", err)
	}

	if l.verbose {
		fmt.Printf("[shark] Compiling IR to object file...\n")
	}

	llcArgs := []string{
		"-filetype=obj",
		"-relocation-model=pic",
		"-O2",
		"-o", objFile,
		llFile,
	}
	llcCmd := exec.Command(l.llcPath, llcArgs...)
	llcCmd.Stderr = os.Stderr
	if l.verbose {
		fmt.Printf("[shark] %s %s\n", l.llcPath, strings.Join(llcArgs, " "))
	}
	err = llcCmd.Run()
	if err != nil {
		return fmt.Errorf("llc compilation failed: %w", err)
	}

	if l.verbose {
		fmt.Printf("[shark] Linking executable...\n")
	}

	return l.link(objFile, outputPath)
}

func (l *Linker) link(objFile, outputPath string) error {
	paths := discoverPaths()

	lldArgs := []string{"-o", outputPath}

	if paths.dynLinker != "" {
		lldArgs = append(lldArgs, "-dynamic-linker", paths.dynLinker)
	}

	if paths.crt1 != "" {
		lldArgs = append(lldArgs, paths.crt1)
	}
	if paths.crti != "" {
		lldArgs = append(lldArgs, paths.crti)
	}
	if paths.crtbeginS != "" {
		lldArgs = append(lldArgs, paths.crtbeginS)
	}

	lldArgs = append(lldArgs, objFile)

	for _, dir := range paths.libDirs {
		lldArgs = append(lldArgs, "-L"+dir)
	}

	lldArgs = append(lldArgs, "-lc")
	if paths.hasGcc {
		lldArgs = append(lldArgs, "-lgcc", "--as-needed", "-lgcc_s", "--no-as-needed")
	}

	if paths.crtendS != "" {
		lldArgs = append(lldArgs, paths.crtendS)
	}
	if paths.crtn != "" {
		lldArgs = append(lldArgs, paths.crtn)
	}

	if l.verbose {
		fmt.Printf("[shark] %s %s\n", l.lldPath, strings.Join(lldArgs, " "))
	}

	lldCmd := exec.Command(l.lldPath, lldArgs...)
	var stderrBuf strings.Builder
	lldCmd.Stderr = &stderrBuf

	err := lldCmd.Run()
	if err != nil {
		if l.verbose {
			fmt.Printf("[shark] First attempt failed: %s\n", stderrBuf.String())
			fmt.Printf("[shark] Retrying minimal link...\n")
		}
		return l.linkMinimal(objFile, outputPath, paths)
	}

	if l.verbose {
		fmt.Printf("[shark] Build successful: %s\n", outputPath)
	}
	return nil
}

func (l *Linker) linkMinimal(objFile, outputPath string, paths *pathInfo) error {
	lldArgs := []string{"-o", outputPath}

	if paths.dynLinker != "" {
		lldArgs = append(lldArgs, "-dynamic-linker", paths.dynLinker)
	}

	if paths.crt1 != "" {
		lldArgs = append(lldArgs, paths.crt1)
	}
	if paths.crti != "" {
		lldArgs = append(lldArgs, paths.crti)
	}

	lldArgs = append(lldArgs, objFile)

	for _, dir := range paths.libDirs {
		lldArgs = append(lldArgs, "-L"+dir)
	}

	lldArgs = append(lldArgs, "-lc")

	if paths.crtn != "" {
		lldArgs = append(lldArgs, paths.crtn)
	}

	if l.verbose {
		fmt.Printf("[shark] %s %s\n", l.lldPath, strings.Join(lldArgs, " "))
	}

	lldCmd := exec.Command(l.lldPath, lldArgs...)
	var stderrBuf strings.Builder
	lldCmd.Stderr = &stderrBuf

	err := lldCmd.Run()
	if err != nil {
		return fmt.Errorf("linking failed: %w\n%s", err, stderrBuf.String())
	}

	if l.verbose {
		fmt.Printf("[shark] Build successful: %s\n", outputPath)
	}
	return nil
}

type pathInfo struct {
	crt1      string
	crti      string
	crtn      string
	crtbeginS string
	crtendS   string
	libDirs   []string
	dynLinker string
	hasGcc    bool
}

func discoverPaths() *pathInfo {
	info := &pathInfo{
		libDirs: make([]string, 0),
	}

	gccBin, err := exec.LookPath("gcc")
	if err != nil {
		return fallbackPaths(info)
	}

	output, err := exec.Command(gccBin, "--print-search-dirs").Output()
	if err != nil {
		return fallbackPaths(info)
	}

	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		if strings.HasPrefix(line, "libraries: =") {
			libStr := strings.TrimPrefix(line, "libraries: =")
			for _, p := range strings.Split(libStr, ":") {
				p = strings.TrimSpace(p)
				if p == "" {
					continue
				}
				if fi, err := os.Stat(p); err == nil && fi.IsDir() {
					info.libDirs = append(info.libDirs, p)

					if info.crt1 == "" {
						c1 := filepath.Join(p, "crt1.o")
						if fileExists(c1) {
							info.crt1 = c1
							info.crti = filepath.Join(p, "crti.o")
							info.crtn = filepath.Join(p, "crtn.o")

							dynLinkerPath := filepath.Join(p, "ld-linux-x86-64.so.2")
							if fileExists(dynLinkerPath) {
								info.dynLinker = dynLinkerPath
							}
						}
					}

					crtbeginS := filepath.Join(p, "crtbeginS.o")
					if fileExists(crtbeginS) {
						info.crtbeginS = crtbeginS
						info.crtendS = filepath.Join(p, "crtendS.o")
						info.hasGcc = true
					}
				}
			}
		}
	}

	if info.dynLinker == "" {
		gccLibDir, _ := exec.Command(gccBin, "--print-file-name=libc.so").Output()
		libcPath := strings.TrimSpace(string(gccLibDir))
		if libcPath != "" && libcPath != "libc.so" {
			dir := filepath.Dir(libcPath)
			dynLinkerPath := filepath.Join(dir, "ld-linux-x86-64.so.2")
			if fileExists(dynLinkerPath) {
				info.dynLinker = dynLinkerPath
			}
		}
	}

	if info.dynLinker == "" {
		candidates := []string{
			"/lib64/ld-linux-x86-64.so.2",
			"/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2",
		}
		for _, c := range candidates {
			if fileExists(c) {
				info.dynLinker = c
				break
			}
		}
	}

	return info
}

func fallbackPaths(info *pathInfo) *pathInfo {
	fallbackDirs := []string{
		"/usr/lib/x86_64-linux-gnu",
		"/usr/lib",
		"/lib/x86_64-linux-gnu",
		"/lib",
	}

	for _, d := range fallbackDirs {
		if fi, err := os.Stat(d); err == nil && fi.IsDir() {
			info.libDirs = append(info.libDirs, d)

			if info.crt1 == "" && fileExists(filepath.Join(d, "crt1.o")) {
				info.crt1 = filepath.Join(d, "crt1.o")
				info.crti = filepath.Join(d, "crti.o")
				info.crtn = filepath.Join(d, "crtn.o")
			}
		}
	}

	info.dynLinker = "/lib64/ld-linux-x86-64.so.2"
	return info
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}
