package stdlib

const IOLib = `
# Shark Standard Library: io
# File I/O operations

fn file_open(path: string, mode: string) -> string
    # Opens a file and returns a file handle
    # mode: "r" for read, "w" for write, "a" for append
    return path
end

fn file_read(path: string) -> string
    # Reads the entire contents of a file
    return ""
end

fn file_write(path: string, content: string)
    # Writes content to a file
end

fn file_close(handle: string)
    # Closes a file handle
end

fn file_exists(path: string) -> bool
    return false
end
`

const MathLib = `
# Shark Standard Library: math
# Math operations

fn abs(x: int) -> int
    if x < 0
        return -x
    end
    return x
end

fn max(a: int, b: int) -> int
    if a > b
        return a
    end
    return b
end

fn min(a: int, b: int) -> int
    if a < b
        return a
    end
    return b
end

fn pow(base: int, exp: int) -> int
    let result = 1
    let i = 0
    while i < exp
        result = result * base
        i = i + 1
    end
    return result
end
`

const StringLib = `
# Shark Standard Library: string
# String operations

fn string_repeat(s: string, n: int) -> string
    let result = ""
    let i = 0
    while i < n
        result = result .. s
        i = i + 1
    end
    return result
end

fn string_contains(haystack: string, needle: string) -> bool
    return false
end
`

const NetLib = `
# Shark Standard Library: net
# Networking operations (TCP/UDP sockets)

fn net_connect(proto: string, addr: string) -> int
    # Connects to addr using protocol (tcp/udp)
    # Returns socket file descriptor
    return -1
end

fn net_send(sock: int, data: string) -> int
    # Sends data on socket, returns bytes sent
    return 0
end

fn net_recv(sock: int, bufsize: int) -> string
    # Receives data from socket
    return ""
end

fn net_close(sock: int)
    # Closes socket
end
`

func GetStdlibNames() []string {
	return []string{"io", "math", "string", "net"}
}

func GetStdlib(name string) (string, bool) {
	switch name {
	case "io":
		return IOLib, true
	case "math":
		return MathLib, true
	case "string":
		return StringLib, true
	case "net":
		return NetLib, true
	default:
		return "", false
	}
}
