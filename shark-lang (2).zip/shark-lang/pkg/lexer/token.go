package lexer

import "fmt"

type TokenType int

const (
	// Literals
	TOKEN_INT TokenType = iota
	TOKEN_FLOAT
	TOKEN_STRING
	TOKEN_BOOL
	TOKEN_IDENT
	TOKEN_NIL

	// Keywords
	TOKEN_LET
	TOKEN_CONST
	TOKEN_FN
	TOKEN_RETURN
	TOKEN_IF
	TOKEN_ELIF
	TOKEN_ELSE
	TOKEN_END
	TOKEN_FOR
	TOKEN_IN
	TOKEN_WHILE
	TOKEN_BREAK
	TOKEN_CONTINUE
	TOKEN_IMPORT
	TOKEN_STRUCT
	TOKEN_AND
	TOKEN_OR
	TOKEN_NOT
	TOKEN_TRUE
	TOKEN_FALSE
	TOKEN_DO
	TOKEN_THEN
	TOKEN_LOCAL
	TOKEN_EXPORT

	// Operators
	TOKEN_PLUS
	TOKEN_MINUS
	TOKEN_STAR
	TOKEN_SLASH
	TOKEN_PERCENT
	TOKEN_EQ
	TOKEN_NEQ
	TOKEN_LT
	TOKEN_GT
	TOKEN_LTE
	TOKEN_GTE
	TOKEN_ASSIGN
	TOKEN_DOTDOT
	TOKEN_ARROW
	TOKEN_DOT
	TOKEN_COLON
	TOKEN_COMMA
	TOKEN_HASH

	// Delimiters
	TOKEN_LPAREN
	TOKEN_RPAREN
	TOKEN_LBRACKET
	TOKEN_RBRACKET
	TOKEN_LBRACE
	TOKEN_RBRACE

	// Special
	TOKEN_NEWLINE
	TOKEN_EOF
	TOKEN_ILLEGAL

	// Compound assignment
	TOKEN_PLUS_ASSIGN
	TOKEN_MINUS_ASSIGN
	TOKEN_STAR_ASSIGN
	TOKEN_SLASH_ASSIGN
)

var tokenNames = map[TokenType]string{
	TOKEN_INT:          "INT",
	TOKEN_FLOAT:        "FLOAT",
	TOKEN_STRING:       "STRING",
	TOKEN_BOOL:         "BOOL",
	TOKEN_IDENT:        "IDENT",
	TOKEN_NIL:          "NIL",
	TOKEN_LET:          "LET",
	TOKEN_CONST:        "CONST",
	TOKEN_FN:           "FN",
	TOKEN_RETURN:       "RETURN",
	TOKEN_IF:           "IF",
	TOKEN_ELIF:         "ELIF",
	TOKEN_ELSE:         "ELSE",
	TOKEN_END:          "END",
	TOKEN_FOR:          "FOR",
	TOKEN_IN:           "IN",
	TOKEN_WHILE:        "WHILE",
	TOKEN_BREAK:        "BREAK",
	TOKEN_CONTINUE:     "CONTINUE",
	TOKEN_IMPORT:       "IMPORT",
	TOKEN_STRUCT:       "STRUCT",
	TOKEN_AND:          "AND",
	TOKEN_OR:           "OR",
	TOKEN_NOT:          "NOT",
	TOKEN_TRUE:         "TRUE",
	TOKEN_FALSE:        "FALSE",
	TOKEN_DO:           "DO",
	TOKEN_THEN:         "THEN",
	TOKEN_LOCAL:        "LOCAL",
	TOKEN_EXPORT:       "EXPORT",
	TOKEN_PLUS:         "PLUS",
	TOKEN_MINUS:        "MINUS",
	TOKEN_STAR:         "STAR",
	TOKEN_SLASH:        "SLASH",
	TOKEN_PERCENT:      "PERCENT",
	TOKEN_EQ:           "EQ",
	TOKEN_NEQ:          "NEQ",
	TOKEN_LT:           "LT",
	TOKEN_GT:           "GT",
	TOKEN_LTE:          "LTE",
	TOKEN_GTE:          "GTE",
	TOKEN_ASSIGN:       "ASSIGN",
	TOKEN_DOTDOT:       "DOTDOT",
	TOKEN_ARROW:        "ARROW",
	TOKEN_DOT:          "DOT",
	TOKEN_COLON:        "COLON",
	TOKEN_COMMA:        "COMMA",
	TOKEN_HASH:         "HASH",
	TOKEN_LPAREN:       "LPAREN",
	TOKEN_RPAREN:       "RPAREN",
	TOKEN_LBRACKET:     "LBRACKET",
	TOKEN_RBRACKET:     "RBRACKET",
	TOKEN_LBRACE:       "LBRACE",
	TOKEN_RBRACE:       "RBRACE",
	TOKEN_NEWLINE:      "NEWLINE",
	TOKEN_EOF:          "EOF",
	TOKEN_ILLEGAL:      "ILLEGAL",
	TOKEN_PLUS_ASSIGN:  "PLUS_ASSIGN",
	TOKEN_MINUS_ASSIGN: "MINUS_ASSIGN",
	TOKEN_STAR_ASSIGN:  "STAR_ASSIGN",
	TOKEN_SLASH_ASSIGN: "SLASH_ASSIGN",
}

func (t TokenType) String() string {
	if name, ok := tokenNames[t]; ok {
		return name
	}
	return fmt.Sprintf("UNKNOWN(%d)", int(t))
}

type Token struct {
	Type    TokenType
	Value   string
	Line    int
	Column  int
}

func (t Token) String() string {
	return fmt.Sprintf("Token(%s, %q, line=%d, col=%d)", t.Type, t.Value, t.Line, t.Column)
}

var keywords = map[string]TokenType{
	"let":      TOKEN_LET,
	"const":    TOKEN_CONST,
	"fn":       TOKEN_FN,
	"return":   TOKEN_RETURN,
	"if":       TOKEN_IF,
	"elif":     TOKEN_ELIF,
	"else":     TOKEN_ELSE,
	"end":      TOKEN_END,
	"for":      TOKEN_FOR,
	"in":       TOKEN_IN,
	"while":    TOKEN_WHILE,
	"break":    TOKEN_BREAK,
	"continue": TOKEN_CONTINUE,
	"import":   TOKEN_IMPORT,
	"struct":   TOKEN_STRUCT,
	"and":      TOKEN_AND,
	"or":       TOKEN_OR,
	"not":      TOKEN_NOT,
	"true":     TOKEN_TRUE,
	"false":    TOKEN_FALSE,
	"nil":      TOKEN_NIL,
	"do":       TOKEN_DO,
	"then":     TOKEN_THEN,
	"local":    TOKEN_LOCAL,
	"export":   TOKEN_EXPORT,
}

func LookupKeyword(ident string) TokenType {
	if tok, ok := keywords[ident]; ok {
		return tok
	}
	return TOKEN_IDENT
}
