package lexer

import (
	"fmt"
	"strings"
	"unicode"
)

type Lexer struct {
	source  string
	tokens  []Token
	pos     int
	line    int
	column  int
	start   int
}

func New(source string) *Lexer {
	return &Lexer{
		source: source,
		tokens: make([]Token, 0),
		pos:    0,
		line:   1,
		column: 1,
	}
}

func (l *Lexer) Tokenize() ([]Token, error) {
	for !l.isAtEnd() {
		l.start = l.pos
		err := l.scanToken()
		if err != nil {
			return nil, err
		}
	}
	l.tokens = append(l.tokens, Token{Type: TOKEN_EOF, Value: "", Line: l.line, Column: l.column})
	return l.tokens, nil
}

func (l *Lexer) isAtEnd() bool {
	return l.pos >= len(l.source)
}

func (l *Lexer) peek() byte {
	if l.isAtEnd() {
		return 0
	}
	return l.source[l.pos]
}

func (l *Lexer) peekNext() byte {
	if l.pos+1 >= len(l.source) {
		return 0
	}
	return l.source[l.pos+1]
}

func (l *Lexer) advance() byte {
	ch := l.source[l.pos]
	l.pos++
	if ch == '\n' {
		l.line++
		l.column = 1
	} else {
		l.column++
	}
	return ch
}

func (l *Lexer) match(expected byte) bool {
	if l.isAtEnd() || l.source[l.pos] != expected {
		return false
	}
	l.advance()
	return true
}

func (l *Lexer) addToken(tokenType TokenType, value string) {
	l.tokens = append(l.tokens, Token{
		Type:   tokenType,
		Value:  value,
		Line:   l.line,
		Column: l.column - len(value),
	})
}

func (l *Lexer) scanToken() error {
	ch := l.advance()

	switch ch {
	case '\n':
		l.addToken(TOKEN_NEWLINE, "\\n")
	case '\r':
		// skip
	case ' ', '\t':
		// skip whitespace
	case '#':
		for !l.isAtEnd() && l.peek() != '\n' {
			l.advance()
		}
	case '+':
		if l.match('=') {
			l.addToken(TOKEN_PLUS_ASSIGN, "+=")
		} else {
			l.addToken(TOKEN_PLUS, "+")
		}
	case '-':
		if l.match('>') {
			l.addToken(TOKEN_ARROW, "->")
		} else if l.match('=') {
			l.addToken(TOKEN_MINUS_ASSIGN, "-=")
		} else {
			l.addToken(TOKEN_MINUS, "-")
		}
	case '*':
		if l.match('=') {
			l.addToken(TOKEN_STAR_ASSIGN, "*=")
		} else {
			l.addToken(TOKEN_STAR, "*")
		}
	case '/':
		if l.match('=') {
			l.addToken(TOKEN_SLASH_ASSIGN, "/=")
		} else {
			l.addToken(TOKEN_SLASH, "/")
		}
	case '%':
		l.addToken(TOKEN_PERCENT, "%")
	case '=':
		if l.match('=') {
			l.addToken(TOKEN_EQ, "==")
		} else {
			l.addToken(TOKEN_ASSIGN, "=")
		}
	case '!':
		if l.match('=') {
			l.addToken(TOKEN_NEQ, "!=")
		} else {
			return fmt.Errorf("line %d, col %d: unexpected character '!'", l.line, l.column)
		}
	case '<':
		if l.match('=') {
			l.addToken(TOKEN_LTE, "<=")
		} else {
			l.addToken(TOKEN_LT, "<")
		}
	case '>':
		if l.match('=') {
			l.addToken(TOKEN_GTE, ">=")
		} else {
			l.addToken(TOKEN_GT, ">")
		}
	case '.':
		if l.match('.') {
			l.addToken(TOKEN_DOTDOT, "..")
		} else {
			l.addToken(TOKEN_DOT, ".")
		}
	case ':':
		l.addToken(TOKEN_COLON, ":")
	case ',':
		l.addToken(TOKEN_COMMA, ",")
	case '(':
		l.addToken(TOKEN_LPAREN, "(")
	case ')':
		l.addToken(TOKEN_RPAREN, ")")
	case '[':
		l.addToken(TOKEN_LBRACKET, "[")
	case ']':
		l.addToken(TOKEN_RBRACKET, "]")
	case '{':
		l.addToken(TOKEN_LBRACE, "{")
	case '}':
		l.addToken(TOKEN_RBRACE, "}")
	case '"':
		return l.scanString('"')
	case '\'':
		return l.scanString('\'')
	default:
		if isDigit(ch) {
			l.scanNumber()
		} else if isAlpha(ch) {
			l.scanIdentifier()
		} else {
			return fmt.Errorf("line %d, col %d: unexpected character '%c'", l.line, l.column, ch)
		}
	}

	return nil
}

func (l *Lexer) scanString(quote byte) error {
	startLine := l.line
	startCol := l.column
	var sb strings.Builder

	for !l.isAtEnd() && l.peek() != quote {
		if l.peek() == '\n' {
			return fmt.Errorf("line %d, col %d: unterminated string", startLine, startCol)
		}
		if l.peek() == '\\' {
			l.advance()
			if l.isAtEnd() {
				return fmt.Errorf("line %d, col %d: unterminated string escape", l.line, l.column)
			}
			escaped := l.advance()
			switch escaped {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			case '\\':
				sb.WriteByte('\\')
			case '\'':
				sb.WriteByte('\'')
			case '"':
				sb.WriteByte('"')
			case '0':
				sb.WriteByte(0)
			default:
				sb.WriteByte('\\')
				sb.WriteByte(escaped)
			}
		} else {
			sb.WriteByte(l.advance())
		}
	}

	if l.isAtEnd() {
		return fmt.Errorf("line %d, col %d: unterminated string", startLine, startCol)
	}
	l.advance() // closing quote

	l.addToken(TOKEN_STRING, sb.String())
	return nil
}

func (l *Lexer) scanNumber() {
	start := l.pos - 1
	isFloat := false

	for !l.isAtEnd() && isDigit(l.peek()) {
		l.advance()
	}

	if !l.isAtEnd() && l.peek() == '.' && l.peekNext() != '.' {
		if l.pos+1 < len(l.source) && isDigit(l.peekNext()) {
			isFloat = true
			l.advance() // consume '.'
			for !l.isAtEnd() && isDigit(l.peek()) {
				l.advance()
			}
		}
	}

	value := l.source[start:l.pos]
	if isFloat {
		l.addToken(TOKEN_FLOAT, value)
	} else {
		l.addToken(TOKEN_INT, value)
	}
}

func (l *Lexer) scanIdentifier() {
	start := l.pos - 1

	for !l.isAtEnd() && isAlphaNumeric(l.peek()) {
		l.advance()
	}

	value := l.source[start:l.pos]
	tokenType := LookupKeyword(value)

	if tokenType == TOKEN_TRUE || tokenType == TOKEN_FALSE {
		l.addToken(TOKEN_BOOL, value)
	} else {
		l.addToken(tokenType, value)
	}
}

func isDigit(ch byte) bool {
	return ch >= '0' && ch <= '9'
}

func isAlpha(ch byte) bool {
	return unicode.IsLetter(rune(ch)) || ch == '_'
}

func isAlphaNumeric(ch byte) bool {
	return isAlpha(ch) || isDigit(ch)
}
