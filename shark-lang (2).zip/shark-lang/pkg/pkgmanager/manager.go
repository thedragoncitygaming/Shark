package pkgmanager

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

type PackageManager struct {
	prefix  string
	libDir  string
	verbose bool
}

func New(verbose bool) *PackageManager {
	prefix := os.Getenv("PREFIX")
	if prefix == "" {
		prefix = "/usr/local"
		home := os.Getenv("HOME")
		if home != "" {
			prefix = filepath.Join(home, ".shark")
		}
	}

	libDir := filepath.Join(prefix, "lib", "shark")

	return &PackageManager{
		prefix:  prefix,
		libDir:  libDir,
		verbose: verbose,
	}
}

func (pm *PackageManager) Install(url string) error {
	if pm.verbose {
		fmt.Printf("[shark-pkg] Installing from: %s\n", url)
	}

	pkgName := extractPackageName(url)
	destDir := filepath.Join(pm.libDir, pkgName)

	err := os.MkdirAll(destDir, 0755)
	if err != nil {
		return fmt.Errorf("failed to create library directory: %w", err)
	}

	if pm.verbose {
		fmt.Printf("[shark-pkg] Downloading...\n")
	}

	resp, err := http.Get(url)
	if err != nil {
		return fmt.Errorf("download failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("download failed with status: %d", resp.StatusCode)
	}

	tmpFile, err := os.CreateTemp("", "shark-pkg-*")
	if err != nil {
		return fmt.Errorf("failed to create temp file: %w", err)
	}
	tmpPath := tmpFile.Name()
	defer os.Remove(tmpPath)

	_, err = io.Copy(tmpFile, resp.Body)
	tmpFile.Close()
	if err != nil {
		return fmt.Errorf("download failed: %w", err)
	}

	if strings.HasSuffix(url, ".tar.gz") || strings.HasSuffix(url, ".tgz") {
		err = extractTarGz(tmpPath, destDir)
	} else if strings.HasSuffix(url, ".zip") {
		err = extractZip(tmpPath, destDir)
	} else if strings.HasSuffix(url, ".shk") {
		destFile := filepath.Join(destDir, filepath.Base(url))
		data, readErr := os.ReadFile(tmpPath)
		if readErr != nil {
			return fmt.Errorf("failed to read downloaded file: %w", readErr)
		}
		err = os.WriteFile(destFile, data, 0644)
	} else {
		destFile := filepath.Join(destDir, filepath.Base(url))
		data, readErr := os.ReadFile(tmpPath)
		if readErr != nil {
			return fmt.Errorf("failed to read downloaded file: %w", readErr)
		}
		err = os.WriteFile(destFile, data, 0644)
	}

	if err != nil {
		return fmt.Errorf("extraction failed: %w", err)
	}

	if pm.verbose {
		fmt.Printf("[shark-pkg] Installed '%s' to %s\n", pkgName, destDir)
	} else {
		fmt.Printf("Installed: %s -> %s\n", pkgName, destDir)
	}

	return nil
}

func (pm *PackageManager) Uninstall(name string) error {
	destDir := filepath.Join(pm.libDir, name)

	if _, err := os.Stat(destDir); os.IsNotExist(err) {
		return fmt.Errorf("package '%s' not found", name)
	}

	err := os.RemoveAll(destDir)
	if err != nil {
		return fmt.Errorf("failed to remove package: %w", err)
	}

	fmt.Printf("Uninstalled: %s\n", name)
	return nil
}

func (pm *PackageManager) List() error {
	if _, err := os.Stat(pm.libDir); os.IsNotExist(err) {
		fmt.Println("No packages installed.")
		return nil
	}

	entries, err := os.ReadDir(pm.libDir)
	if err != nil {
		return fmt.Errorf("failed to read lib directory: %w", err)
	}

	if len(entries) == 0 {
		fmt.Println("No packages installed.")
		return nil
	}

	fmt.Printf("Installed packages (%s):\n", pm.libDir)
	for _, entry := range entries {
		if entry.IsDir() {
			files, _ := os.ReadDir(filepath.Join(pm.libDir, entry.Name()))
			fmt.Printf("  %s/ (%d files)\n", entry.Name(), len(files))
		}
	}

	return nil
}

func (pm *PackageManager) GetLibPath(name string) string {
	return filepath.Join(pm.libDir, name)
}

func (pm *PackageManager) GetLibDir() string {
	return pm.libDir
}

func extractPackageName(url string) string {
	base := filepath.Base(url)

	base = strings.TrimSuffix(base, ".tar.gz")
	base = strings.TrimSuffix(base, ".tgz")
	base = strings.TrimSuffix(base, ".zip")
	base = strings.TrimSuffix(base, ".shk")

	base = strings.ReplaceAll(base, " ", "_")
	base = strings.ReplaceAll(base, "-", "_")

	if base == "" {
		base = "unknown_pkg"
	}

	return base
}

func extractTarGz(src, dest string) error {
	f, err := os.Open(src)
	if err != nil {
		return err
	}
	defer f.Close()

	gzr, err := gzip.NewReader(f)
	if err != nil {
		return err
	}
	defer gzr.Close()

	tr := tar.NewReader(gzr)

	for {
		header, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}

		target := filepath.Join(dest, header.Name)

		if !strings.HasPrefix(filepath.Clean(target), filepath.Clean(dest)) {
			return fmt.Errorf("invalid path in archive: %s", header.Name)
		}

		switch header.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0755); err != nil {
				return err
			}
		case tar.TypeReg:
			dir := filepath.Dir(target)
			if err := os.MkdirAll(dir, 0755); err != nil {
				return err
			}
			outFile, err := os.Create(target)
			if err != nil {
				return err
			}
			if _, err := io.Copy(outFile, tr); err != nil {
				outFile.Close()
				return err
			}
			outFile.Close()
			os.Chmod(target, os.FileMode(header.Mode))
		}
	}

	return nil
}

func extractZip(src, dest string) error {
	r, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer r.Close()

	for _, f := range r.File {
		target := filepath.Join(dest, f.Name)

		if !strings.HasPrefix(filepath.Clean(target), filepath.Clean(dest)) {
			return fmt.Errorf("invalid path in archive: %s", f.Name)
		}

		if f.FileInfo().IsDir() {
			os.MkdirAll(target, 0755)
			continue
		}

		dir := filepath.Dir(target)
		os.MkdirAll(dir, 0755)

		rc, err := f.Open()
		if err != nil {
			return err
		}

		outFile, err := os.Create(target)
		if err != nil {
			rc.Close()
			return err
		}

		_, err = io.Copy(outFile, rc)
		outFile.Close()
		rc.Close()
		if err != nil {
			return err
		}
	}

	return nil
}
