package parser

import (
        "fmt"
        "shark-lang/pkg/lexer"
        "strconv"
)

type Parser struct {
        tokens  []lexer.Token
        pos     int
        current lexer.Token
}

func New(tokens []lexer.Token) *Parser {
        p := &Parser{
                tokens: tokens,
                pos:    0,
        }
        if len(tokens) > 0 {
                p.current = tokens[0]
        }
        return p
}

func (p *Parser) Parse() (*Program, error) {
        program := &Program{Statements: make([]Node, 0)}

        p.skipNewlines()
        for p.current.Type != lexer.TOKEN_EOF {
                stmt, err := p.parseStatement()
                if err != nil {
                        return nil, err
                }
                if stmt != nil {
                        program.Statements = append(program.Statements, stmt)
                }
                p.skipNewlines()
        }

        return program, nil
}

func (p *Parser) advance() lexer.Token {
        prev := p.current
        p.pos++
        if p.pos < len(p.tokens) {
                p.current = p.tokens[p.pos]
        }
        return prev
}

func (p *Parser) peek() lexer.Token {
        return p.current
}

func (p *Parser) peekNext() lexer.Token {
        nextPos := p.pos + 1
        for nextPos < len(p.tokens) && p.tokens[nextPos].Type == lexer.TOKEN_NEWLINE {
                nextPos++
        }
        if nextPos < len(p.tokens) {
                return p.tokens[nextPos]
        }
        return lexer.Token{Type: lexer.TOKEN_EOF}
}

func (p *Parser) expect(tokenType lexer.TokenType) (lexer.Token, error) {
        if p.current.Type != tokenType {
                return lexer.Token{}, fmt.Errorf("line %d: expected %s, got %s (%q)",
                        p.current.Line, tokenType, p.current.Type, p.current.Value)
        }
        return p.advance(), nil
}

func (p *Parser) match(types ...lexer.TokenType) bool {
        for _, t := range types {
                if p.current.Type == t {
                        return true
                }
        }
        return false
}

func (p *Parser) skipNewlines() {
        for p.current.Type == lexer.TOKEN_NEWLINE {
                p.advance()
        }
}

func (p *Parser) expectNewlineOrEOF() error {
        if p.current.Type != lexer.TOKEN_NEWLINE && p.current.Type != lexer.TOKEN_EOF {
                return fmt.Errorf("line %d: expected newline or EOF, got %s (%q)",
                        p.current.Line, p.current.Type, p.current.Value)
        }
        if p.current.Type == lexer.TOKEN_NEWLINE {
                p.advance()
        }
        return nil
}

func (p *Parser) parseStatement() (Node, error) {
        switch p.current.Type {
        case lexer.TOKEN_LET, lexer.TOKEN_CONST:
                return p.parseLetStatement()
        case lexer.TOKEN_FN:
                return p.parseFunctionDecl(false)
        case lexer.TOKEN_EXPORT:
                p.advance()
                if p.current.Type == lexer.TOKEN_FN {
                        return p.parseFunctionDecl(true)
                }
                return nil, fmt.Errorf("line %d: export must be followed by fn", p.current.Line)
        case lexer.TOKEN_RETURN:
                return p.parseReturnStatement()
        case lexer.TOKEN_IF:
                return p.parseIfStatement()
        case lexer.TOKEN_WHILE:
                return p.parseWhileStatement()
        case lexer.TOKEN_FOR:
                return p.parseForStatement()
        case lexer.TOKEN_BREAK:
                line := p.current.Line
                p.advance()
                p.expectNewlineOrEOF()
                return &BreakStatement{Line: line}, nil
        case lexer.TOKEN_CONTINUE:
                line := p.current.Line
                p.advance()
                p.expectNewlineOrEOF()
                return &ContinueStatement{Line: line}, nil
        case lexer.TOKEN_IMPORT:
                return p.parseImportStatement()
        case lexer.TOKEN_STRUCT:
                return p.parseStructDecl()
        default:
                return p.parseExpressionStatement()
        }
}

func (p *Parser) parseLetStatement() (Node, error) {
        isConst := p.current.Type == lexer.TOKEN_CONST
        line := p.current.Line
        p.advance()

        name, err := p.expect(lexer.TOKEN_IDENT)
        if err != nil {
                return nil, err
        }

        var typeHint *TypeAnnotation
        if p.current.Type == lexer.TOKEN_COLON {
                p.advance()
                typeHint, err = p.parseTypeAnnotation()
                if err != nil {
                        return nil, err
                }
        }

        _, err = p.expect(lexer.TOKEN_ASSIGN)
        if err != nil {
                return nil, err
        }

        value, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        err = p.expectNewlineOrEOF()
        if err != nil {
                return nil, err
        }

        return &LetStatement{
                Name:     name.Value,
                TypeHint: typeHint,
                Value:    value,
                IsConst:  isConst,
                Line:     line,
        }, nil
}

func (p *Parser) parseTypeAnnotation() (*TypeAnnotation, error) {
        if p.current.Type == lexer.TOKEN_LBRACKET {
                p.advance()
                elemType, err := p.parseTypeAnnotation()
                if err != nil {
                        return nil, err
                }
                _, err = p.expect(lexer.TOKEN_RBRACKET)
                if err != nil {
                        return nil, err
                }
                return &TypeAnnotation{Name: "array", IsArray: true, ElemType: elemType}, nil
        }

        name, err := p.expect(lexer.TOKEN_IDENT)
        if err != nil {
                return nil, err
        }
        return &TypeAnnotation{Name: name.Value}, nil
}

func (p *Parser) parseFunctionDecl(isExport bool) (Node, error) {
        line := p.current.Line
        p.advance() // consume 'fn'

        name, err := p.expect(lexer.TOKEN_IDENT)
        if err != nil {
                return nil, err
        }

        _, err = p.expect(lexer.TOKEN_LPAREN)
        if err != nil {
                return nil, err
        }

        params := make([]FuncParam, 0)
        for p.current.Type != lexer.TOKEN_RPAREN {
                paramName, err := p.expect(lexer.TOKEN_IDENT)
                if err != nil {
                        return nil, err
                }

                var typeHint *TypeAnnotation
                if p.current.Type == lexer.TOKEN_COLON {
                        p.advance()
                        typeHint, err = p.parseTypeAnnotation()
                        if err != nil {
                                return nil, err
                        }
                }

                params = append(params, FuncParam{Name: paramName.Value, TypeHint: typeHint})

                if p.current.Type == lexer.TOKEN_COMMA {
                        p.advance()
                }
        }

        _, err = p.expect(lexer.TOKEN_RPAREN)
        if err != nil {
                return nil, err
        }

        var returnType *TypeAnnotation
        if p.current.Type == lexer.TOKEN_ARROW {
                p.advance()
                returnType, err = p.parseTypeAnnotation()
                if err != nil {
                        return nil, err
                }
        }

        p.skipNewlines()

        body, err := p.parseBlock()
        if err != nil {
                return nil, err
        }

        _, err = p.expect(lexer.TOKEN_END)
        if err != nil {
                return nil, err
        }
        p.expectNewlineOrEOF()

        return &FunctionDecl{
                Name:       name.Value,
                Params:     params,
                ReturnType: returnType,
                Body:       body,
                IsExport:   isExport,
                Line:       line,
        }, nil
}

func (p *Parser) parseBlock() ([]Node, error) {
        stmts := make([]Node, 0)

        p.skipNewlines()
        for !p.match(lexer.TOKEN_END, lexer.TOKEN_ELSE, lexer.TOKEN_ELIF, lexer.TOKEN_EOF) {
                stmt, err := p.parseStatement()
                if err != nil {
                        return nil, err
                }
                if stmt != nil {
                        stmts = append(stmts, stmt)
                }
                p.skipNewlines()
        }

        return stmts, nil
}

func (p *Parser) parseReturnStatement() (Node, error) {
        line := p.current.Line
        p.advance()

        var value Node
        if p.current.Type != lexer.TOKEN_NEWLINE && p.current.Type != lexer.TOKEN_EOF {
                var err error
                value, err = p.parseExpression()
                if err != nil {
                        return nil, err
                }
        }

        p.expectNewlineOrEOF()

        return &ReturnStatement{Value: value, Line: line}, nil
}

func (p *Parser) parseIfStatement() (Node, error) {
        line := p.current.Line
        p.advance() // consume 'if'

        condition, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        p.skipNewlines()

        body, err := p.parseBlock()
        if err != nil {
                return nil, err
        }

        elseIfs := make([]ElseIfClause, 0)
        var elseBody []Node

        for p.current.Type == lexer.TOKEN_ELIF {
                p.advance()
                elifCond, err := p.parseExpression()
                if err != nil {
                        return nil, err
                }
                p.skipNewlines()
                elifBody, err := p.parseBlock()
                if err != nil {
                        return nil, err
                }
                elseIfs = append(elseIfs, ElseIfClause{Condition: elifCond, Body: elifBody})
        }

        if p.current.Type == lexer.TOKEN_ELSE {
                p.advance()
                p.skipNewlines()
                elseBody, err = p.parseBlock()
                if err != nil {
                        return nil, err
                }
        }

        _, err = p.expect(lexer.TOKEN_END)
        if err != nil {
                return nil, err
        }
        p.expectNewlineOrEOF()

        return &IfStatement{
                Condition: condition,
                Body:      body,
                ElseIfs:   elseIfs,
                ElseBody:  elseBody,
                Line:      line,
        }, nil
}

func (p *Parser) parseWhileStatement() (Node, error) {
        line := p.current.Line
        p.advance()

        condition, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        p.skipNewlines()

        body, err := p.parseBlock()
        if err != nil {
                return nil, err
        }

        _, err = p.expect(lexer.TOKEN_END)
        if err != nil {
                return nil, err
        }
        p.expectNewlineOrEOF()

        return &WhileStatement{
                Condition: condition,
                Body:      body,
                Line:      line,
        }, nil
}

func (p *Parser) parseForStatement() (Node, error) {
        line := p.current.Line
        p.advance()

        varName, err := p.expect(lexer.TOKEN_IDENT)
        if err != nil {
                return nil, err
        }

        _, err = p.expect(lexer.TOKEN_IN)
        if err != nil {
                return nil, err
        }

        iterable, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        p.skipNewlines()

        body, err := p.parseBlock()
        if err != nil {
                return nil, err
        }

        _, err = p.expect(lexer.TOKEN_END)
        if err != nil {
                return nil, err
        }
        p.expectNewlineOrEOF()

        return &ForStatement{
                Variable: varName.Value,
                Iterable: iterable,
                Body:     body,
                Line:     line,
        }, nil
}

func (p *Parser) parseImportStatement() (Node, error) {
        line := p.current.Line
        p.advance()

        path, err := p.expect(lexer.TOKEN_STRING)
        if err != nil {
                if p.current.Type == lexer.TOKEN_IDENT {
                        tok := p.advance()
                        p.expectNewlineOrEOF()
                        return &ImportStatement{Path: tok.Value, Alias: tok.Value, Line: line}, nil
                }
                return nil, err
        }

        alias := ""
        // Extract alias from path (last component)
        for i := len(path.Value) - 1; i >= 0; i-- {
                if path.Value[i] == '/' {
                        alias = path.Value[i+1:]
                        break
                }
        }
        if alias == "" {
                alias = path.Value
        }

        p.expectNewlineOrEOF()

        return &ImportStatement{Path: path.Value, Alias: alias, Line: line}, nil
}

func (p *Parser) parseStructDecl() (Node, error) {
        line := p.current.Line
        p.advance()

        name, err := p.expect(lexer.TOKEN_IDENT)
        if err != nil {
                return nil, err
        }

        p.skipNewlines()

        fields := make([]StructField, 0)
        for p.current.Type != lexer.TOKEN_END && p.current.Type != lexer.TOKEN_EOF {
                fieldName, err := p.expect(lexer.TOKEN_IDENT)
                if err != nil {
                        return nil, err
                }

                _, err = p.expect(lexer.TOKEN_COLON)
                if err != nil {
                        return nil, err
                }

                typeHint, err := p.parseTypeAnnotation()
                if err != nil {
                        return nil, err
                }

                fields = append(fields, StructField{Name: fieldName.Value, TypeHint: typeHint})
                p.skipNewlines()
        }

        _, err = p.expect(lexer.TOKEN_END)
        if err != nil {
                return nil, err
        }
        p.expectNewlineOrEOF()

        return &StructDecl{Name: name.Value, Fields: fields, Line: line}, nil
}

func (p *Parser) parseExpressionStatement() (Node, error) {
        line := p.current.Line
        expr, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        if p.match(lexer.TOKEN_ASSIGN, lexer.TOKEN_PLUS_ASSIGN, lexer.TOKEN_MINUS_ASSIGN,
                lexer.TOKEN_STAR_ASSIGN, lexer.TOKEN_SLASH_ASSIGN) {
                op := p.advance()
                value, err := p.parseExpression()
                if err != nil {
                        return nil, err
                }
                p.expectNewlineOrEOF()
                return &AssignStatement{Target: expr, Value: value, Op: op.Value, Line: line}, nil
        }

        p.expectNewlineOrEOF()
        return &ExpressionStatement{Expression: expr, Line: line}, nil
}

func (p *Parser) parseExpression() (Node, error) {
        return p.parseOr()
}

func (p *Parser) parseOr() (Node, error) {
        left, err := p.parseAnd()
        if err != nil {
                return nil, err
        }

        for p.current.Type == lexer.TOKEN_OR {
                op := p.advance()
                right, err := p.parseAnd()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseAnd() (Node, error) {
        left, err := p.parseNot()
        if err != nil {
                return nil, err
        }

        for p.current.Type == lexer.TOKEN_AND {
                op := p.advance()
                right, err := p.parseNot()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseNot() (Node, error) {
        if p.current.Type == lexer.TOKEN_NOT {
                op := p.advance()
                operand, err := p.parseNot()
                if err != nil {
                        return nil, err
                }
                return &UnaryExpr{Operator: op.Value, Operand: operand, Line: op.Line}, nil
        }
        return p.parseComparison()
}

func (p *Parser) parseComparison() (Node, error) {
        left, err := p.parseConcatenation()
        if err != nil {
                return nil, err
        }

        for p.match(lexer.TOKEN_EQ, lexer.TOKEN_NEQ, lexer.TOKEN_LT, lexer.TOKEN_GT,
                lexer.TOKEN_LTE, lexer.TOKEN_GTE) {
                op := p.advance()
                right, err := p.parseConcatenation()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseConcatenation() (Node, error) {
        left, err := p.parseAddition()
        if err != nil {
                return nil, err
        }

        for p.current.Type == lexer.TOKEN_DOTDOT {
                op := p.advance()
                right, err := p.parseAddition()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseAddition() (Node, error) {
        left, err := p.parseMultiplication()
        if err != nil {
                return nil, err
        }

        for p.match(lexer.TOKEN_PLUS, lexer.TOKEN_MINUS) {
                op := p.advance()
                right, err := p.parseMultiplication()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseMultiplication() (Node, error) {
        left, err := p.parseUnary()
        if err != nil {
                return nil, err
        }

        for p.match(lexer.TOKEN_STAR, lexer.TOKEN_SLASH, lexer.TOKEN_PERCENT) {
                op := p.advance()
                right, err := p.parseUnary()
                if err != nil {
                        return nil, err
                }
                left = &BinaryExpr{Left: left, Operator: op.Value, Right: right, Line: op.Line}
        }

        return left, nil
}

func (p *Parser) parseUnary() (Node, error) {
        if p.current.Type == lexer.TOKEN_MINUS {
                op := p.advance()
                operand, err := p.parseUnary()
                if err != nil {
                        return nil, err
                }
                return &UnaryExpr{Operator: op.Value, Operand: operand, Line: op.Line}, nil
        }
        return p.parsePostfix()
}

func (p *Parser) parsePostfix() (Node, error) {
        expr, err := p.parsePrimary()
        if err != nil {
                return nil, err
        }

        for {
                if p.current.Type == lexer.TOKEN_LPAREN {
                        p.advance()
                        args := make([]Node, 0)
                        for p.current.Type != lexer.TOKEN_RPAREN {
                                arg, err := p.parseExpression()
                                if err != nil {
                                        return nil, err
                                }
                                args = append(args, arg)
                                if p.current.Type == lexer.TOKEN_COMMA {
                                        p.advance()
                                }
                        }
                        _, err := p.expect(lexer.TOKEN_RPAREN)
                        if err != nil {
                                return nil, err
                        }
                        expr = &CallExpr{Callee: expr, Args: args, Line: p.current.Line}
                } else if p.current.Type == lexer.TOKEN_LBRACKET {
                        p.advance()
                        index, err := p.parseExpression()
                        if err != nil {
                                return nil, err
                        }
                        _, err = p.expect(lexer.TOKEN_RBRACKET)
                        if err != nil {
                                return nil, err
                        }
                        expr = &IndexExpr{Object: expr, Index: index, Line: p.current.Line}
                } else if p.current.Type == lexer.TOKEN_DOT {
                        p.advance()
                        member, err := p.expect(lexer.TOKEN_IDENT)
                        if err != nil {
                                return nil, err
                        }
                        expr = &MemberExpr{Object: expr, Member: member.Value, Line: member.Line}
                } else {
                        break
                }
        }

        return expr, nil
}

func (p *Parser) parsePrimary() (Node, error) {
        switch p.current.Type {
        case lexer.TOKEN_INT:
                tok := p.advance()
                val, err := strconv.ParseInt(tok.Value, 10, 64)
                if err != nil {
                        return nil, fmt.Errorf("line %d: invalid integer: %s", tok.Line, tok.Value)
                }
                return &IntLiteral{Value: val, Line: tok.Line}, nil

        case lexer.TOKEN_FLOAT:
                tok := p.advance()
                val, err := strconv.ParseFloat(tok.Value, 64)
                if err != nil {
                        return nil, fmt.Errorf("line %d: invalid float: %s", tok.Line, tok.Value)
                }
                return &FloatLiteral{Value: val, Line: tok.Line}, nil

        case lexer.TOKEN_STRING:
                tok := p.advance()
                return &StringLiteral{Value: tok.Value, Line: tok.Line}, nil

        case lexer.TOKEN_BOOL:
                tok := p.advance()
                return &BoolLiteral{Value: tok.Value == "true", Line: tok.Line}, nil

        case lexer.TOKEN_NIL:
                tok := p.advance()
                return &NilLiteral{Line: tok.Line}, nil

        case lexer.TOKEN_IDENT:
                tok := p.advance()
                if tok.Value == "range" && p.current.Type == lexer.TOKEN_LPAREN {
                        return p.parseRangeExpr(tok.Line)
                }
                return &Identifier{Name: tok.Value, Line: tok.Line}, nil

        case lexer.TOKEN_LPAREN:
                p.advance()
                expr, err := p.parseExpression()
                if err != nil {
                        return nil, err
                }
                _, err = p.expect(lexer.TOKEN_RPAREN)
                if err != nil {
                        return nil, err
                }
                return expr, nil

        case lexer.TOKEN_LBRACKET:
                return p.parseArrayLiteral()

        default:
                return nil, fmt.Errorf("line %d: unexpected token %s (%q)",
                        p.current.Line, p.current.Type, p.current.Value)
        }
}

func (p *Parser) parseRangeExpr(line int) (Node, error) {
        p.advance() // consume '('

        start, err := p.parseExpression()
        if err != nil {
                return nil, err
        }

        var end Node
        var step Node

        if p.current.Type == lexer.TOKEN_COMMA {
                p.advance()
                end, err = p.parseExpression()
                if err != nil {
                        return nil, err
                }

                if p.current.Type == lexer.TOKEN_COMMA {
                        p.advance()
                        step, err = p.parseExpression()
                        if err != nil {
                                return nil, err
                        }
                }
        } else {
                end = start
                start = &IntLiteral{Value: 0, Line: line}
        }

        _, err = p.expect(lexer.TOKEN_RPAREN)
        if err != nil {
                return nil, err
        }

        return &RangeExpr{Start: start, End: end, Step: step, Line: line}, nil
}

func (p *Parser) parseArrayLiteral() (Node, error) {
        line := p.current.Line
        p.advance() // consume '['

        elements := make([]Node, 0)
        for p.current.Type != lexer.TOKEN_RBRACKET {
                elem, err := p.parseExpression()
                if err != nil {
                        return nil, err
                }
                elements = append(elements, elem)
                if p.current.Type == lexer.TOKEN_COMMA {
                        p.advance()
                }
        }

        _, err := p.expect(lexer.TOKEN_RBRACKET)
        if err != nil {
                return nil, err
        }

        return &ArrayLiteral{Elements: elements, Line: line}, nil
}
