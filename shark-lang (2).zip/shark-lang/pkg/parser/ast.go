package parser

type Node interface {
	nodeType() string
}

type Program struct {
	Statements []Node
}

func (p *Program) nodeType() string { return "Program" }

type TypeAnnotation struct {
	Name     string
	IsArray  bool
	ElemType *TypeAnnotation
}

type LetStatement struct {
	Name     string
	TypeHint *TypeAnnotation
	Value    Node
	IsConst  bool
	Line     int
}

func (l *LetStatement) nodeType() string { return "LetStatement" }

type AssignStatement struct {
	Target Node
	Value  Node
	Op     string
	Line   int
}

func (a *AssignStatement) nodeType() string { return "AssignStatement" }

type FunctionDecl struct {
	Name       string
	Params     []FuncParam
	ReturnType *TypeAnnotation
	Body       []Node
	IsExport   bool
	Line       int
}

type FuncParam struct {
	Name     string
	TypeHint *TypeAnnotation
}

func (f *FunctionDecl) nodeType() string { return "FunctionDecl" }

type ReturnStatement struct {
	Value Node
	Line  int
}

func (r *ReturnStatement) nodeType() string { return "ReturnStatement" }

type IfStatement struct {
	Condition Node
	Body      []Node
	ElseIfs   []ElseIfClause
	ElseBody  []Node
	Line      int
}

type ElseIfClause struct {
	Condition Node
	Body      []Node
}

func (i *IfStatement) nodeType() string { return "IfStatement" }

type WhileStatement struct {
	Condition Node
	Body      []Node
	Line      int
}

func (w *WhileStatement) nodeType() string { return "WhileStatement" }

type ForStatement struct {
	Variable string
	Iterable Node
	Body     []Node
	Line     int
}

func (f *ForStatement) nodeType() string { return "ForStatement" }

type BreakStatement struct {
	Line int
}

func (b *BreakStatement) nodeType() string { return "BreakStatement" }

type ContinueStatement struct {
	Line int
}

func (c *ContinueStatement) nodeType() string { return "ContinueStatement" }

type ImportStatement struct {
	Path  string
	Alias string
	Line  int
}

func (i *ImportStatement) nodeType() string { return "ImportStatement" }

type StructDecl struct {
	Name   string
	Fields []StructField
	Line   int
}

type StructField struct {
	Name     string
	TypeHint *TypeAnnotation
}

func (s *StructDecl) nodeType() string { return "StructDecl" }

type BinaryExpr struct {
	Left     Node
	Operator string
	Right    Node
	Line     int
}

func (b *BinaryExpr) nodeType() string { return "BinaryExpr" }

type UnaryExpr struct {
	Operator string
	Operand  Node
	Line     int
}

func (u *UnaryExpr) nodeType() string { return "UnaryExpr" }

type CallExpr struct {
	Callee Node
	Args   []Node
	Line   int
}

func (c *CallExpr) nodeType() string { return "CallExpr" }

type IndexExpr struct {
	Object Node
	Index  Node
	Line   int
}

func (i *IndexExpr) nodeType() string { return "IndexExpr" }

type MemberExpr struct {
	Object Node
	Member string
	Line   int
}

func (m *MemberExpr) nodeType() string { return "MemberExpr" }

type IntLiteral struct {
	Value int64
	Line  int
}

func (i *IntLiteral) nodeType() string { return "IntLiteral" }

type FloatLiteral struct {
	Value float64
	Line  int
}

func (f *FloatLiteral) nodeType() string { return "FloatLiteral" }

type StringLiteral struct {
	Value string
	Line  int
}

func (s *StringLiteral) nodeType() string { return "StringLiteral" }

type BoolLiteral struct {
	Value bool
	Line  int
}

func (b *BoolLiteral) nodeType() string { return "BoolLiteral" }

type NilLiteral struct {
	Line int
}

func (n *NilLiteral) nodeType() string { return "NilLiteral" }

type Identifier struct {
	Name string
	Line int
}

func (i *Identifier) nodeType() string { return "Identifier" }

type ArrayLiteral struct {
	Elements []Node
	Line     int
}

func (a *ArrayLiteral) nodeType() string { return "ArrayLiteral" }

type StructLiteral struct {
	Name   string
	Fields map[string]Node
	Line   int
}

func (s *StructLiteral) nodeType() string { return "StructLiteral" }

type ExpressionStatement struct {
	Expression Node
	Line       int
}

func (e *ExpressionStatement) nodeType() string { return "ExpressionStatement" }

type RangeExpr struct {
	Start Node
	End   Node
	Step  Node
	Line  int
}

func (r *RangeExpr) nodeType() string { return "RangeExpr" }
