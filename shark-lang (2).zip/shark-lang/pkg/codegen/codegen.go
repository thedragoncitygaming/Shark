package codegen

import (
        "fmt"
        "shark-lang/pkg/parser"

        "github.com/llir/llvm/ir"
        "github.com/llir/llvm/ir/constant"
        "github.com/llir/llvm/ir/enum"
        "github.com/llir/llvm/ir/types"
        "github.com/llir/llvm/ir/value"
)

type CodeGen struct {
        module    *ir.Module
        builder   *ir.Block
        function  *ir.Func
        scope     *CodeGenScope
        strings   map[string]*ir.Global
        strCount  int
        tmpCount  int
        functions map[string]*ir.Func
        structs   map[string]*types.StructType
        structFieldIndices map[string]map[string]int

        breakBlock    *ir.Block
        continueBlock *ir.Block

        printfFunc    *ir.Func
        putsFunc      *ir.Func
        sprintfFunc   *ir.Func
        scanfFunc     *ir.Func
        mallocFunc    *ir.Func
        freeFunc      *ir.Func
        strlenFunc    *ir.Func
        strcatFunc    *ir.Func
        strcpyFunc    *ir.Func
        exitFunc      *ir.Func
        atoiFunc      *ir.Func
        atofFunc      *ir.Func
        snprintfFunc  *ir.Func
        memcpyFunc    *ir.Func
        getlineFunc   *ir.Func
        stdinGlobal   *ir.Global

        socketFunc    *ir.Func
        connectFunc   *ir.Func
        sendFunc      *ir.Func
        recvFunc      *ir.Func
        closeFunc     *ir.Func
        htonsFn       *ir.Func
        inetPtonFn    *ir.Func
        getaddrinfoFn *ir.Func
        freeaddrinfoFn *ir.Func

        fopenFunc     *ir.Func
        fwriteFunc    *ir.Func
        freadFunc     *ir.Func
        fcloseFunc    *ir.Func
        fgetsFunc     *ir.Func
}

type CodeGenScope struct {
        parent *CodeGenScope
        vars   map[string]value.Value
        types  map[string]types.Type
}

func NewCodeGenScope(parent *CodeGenScope) *CodeGenScope {
        return &CodeGenScope{
                parent: parent,
                vars:   make(map[string]value.Value),
                types:  make(map[string]types.Type),
        }
}

func (s *CodeGenScope) Set(name string, val value.Value) {
        s.vars[name] = val
}

func (s *CodeGenScope) SetType(name string, t types.Type) {
        s.types[name] = t
}

func (s *CodeGenScope) Get(name string) (value.Value, bool) {
        if v, ok := s.vars[name]; ok {
                return v, true
        }
        if s.parent != nil {
                return s.parent.Get(name)
        }
        return nil, false
}

func (s *CodeGenScope) GetType(name string) (types.Type, bool) {
        if t, ok := s.types[name]; ok {
                return t, true
        }
        if s.parent != nil {
                return s.parent.GetType(name)
        }
        return nil, false
}

func New() *CodeGen {
        m := ir.NewModule()
        m.TargetTriple = "x86_64-unknown-linux-gnu"
        m.DataLayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"

        cg := &CodeGen{
                module:    m,
                scope:     NewCodeGenScope(nil),
                strings:   make(map[string]*ir.Global),
                functions: make(map[string]*ir.Func),
                structs:   make(map[string]*types.StructType),
                structFieldIndices: make(map[string]map[string]int),
        }

        cg.declareExternFunctions()
        return cg
}

func (cg *CodeGen) declareExternFunctions() {
        i8Ptr := types.I8Ptr
        i32 := types.I32
        i64 := types.I64
        voidTy := types.Void

        cg.printfFunc = cg.module.NewFunc("printf", i32, ir.NewParam("fmt", i8Ptr))
        cg.printfFunc.Sig.Variadic = true

        cg.putsFunc = cg.module.NewFunc("puts", i32, ir.NewParam("s", i8Ptr))

        cg.sprintfFunc = cg.module.NewFunc("sprintf", i32, ir.NewParam("buf", i8Ptr), ir.NewParam("fmt", i8Ptr))
        cg.sprintfFunc.Sig.Variadic = true

        cg.snprintfFunc = cg.module.NewFunc("snprintf", i32, ir.NewParam("buf", i8Ptr), ir.NewParam("size", i64), ir.NewParam("fmt", i8Ptr))
        cg.snprintfFunc.Sig.Variadic = true

        cg.scanfFunc = cg.module.NewFunc("scanf", i32, ir.NewParam("fmt", i8Ptr))
        cg.scanfFunc.Sig.Variadic = true

        cg.mallocFunc = cg.module.NewFunc("malloc", i8Ptr, ir.NewParam("size", i64))
        cg.freeFunc = cg.module.NewFunc("free", voidTy, ir.NewParam("ptr", i8Ptr))
        cg.strlenFunc = cg.module.NewFunc("strlen", i64, ir.NewParam("s", i8Ptr))
        cg.strcatFunc = cg.module.NewFunc("strcat", i8Ptr, ir.NewParam("dest", i8Ptr), ir.NewParam("src", i8Ptr))
        cg.strcpyFunc = cg.module.NewFunc("strcpy", i8Ptr, ir.NewParam("dest", i8Ptr), ir.NewParam("src", i8Ptr))
        cg.exitFunc = cg.module.NewFunc("exit", voidTy, ir.NewParam("status", i32))
        cg.atoiFunc = cg.module.NewFunc("atoi", i32, ir.NewParam("s", i8Ptr))
        cg.atofFunc = cg.module.NewFunc("atof", types.Double, ir.NewParam("s", i8Ptr))

        cg.memcpyFunc = cg.module.NewFunc("memcpy", i8Ptr,
                ir.NewParam("dest", i8Ptr),
                ir.NewParam("src", i8Ptr),
                ir.NewParam("n", i64))

        stdinTy := types.I8Ptr
        cg.stdinGlobal = cg.module.NewGlobal("stdin", stdinTy)
        cg.stdinGlobal.ExternallyInitialized = true
        cg.stdinGlobal.Linkage = enum.LinkageExternal

        cg.getlineFunc = cg.module.NewFunc("getline",
                i64,
                ir.NewParam("lineptr", types.NewPointer(i8Ptr)),
                ir.NewParam("n", types.NewPointer(i64)),
                ir.NewParam("stream", i8Ptr))

        cg.socketFunc = cg.module.NewFunc("socket", i32,
                ir.NewParam("domain", i32),
                ir.NewParam("type", i32),
                ir.NewParam("protocol", i32))
        cg.connectFunc = cg.module.NewFunc("connect", i32,
                ir.NewParam("sockfd", i32),
                ir.NewParam("addr", i8Ptr),
                ir.NewParam("addrlen", i32))
        cg.sendFunc = cg.module.NewFunc("send", i64,
                ir.NewParam("sockfd", i32),
                ir.NewParam("buf", i8Ptr),
                ir.NewParam("len", i64),
                ir.NewParam("flags", i32))
        cg.recvFunc = cg.module.NewFunc("recv", i64,
                ir.NewParam("sockfd", i32),
                ir.NewParam("buf", i8Ptr),
                ir.NewParam("len", i64),
                ir.NewParam("flags", i32))
        cg.closeFunc = cg.module.NewFunc("close", i32, ir.NewParam("fd", i32))

        cg.fopenFunc = cg.module.NewFunc("fopen", i8Ptr,
                ir.NewParam("filename", i8Ptr),
                ir.NewParam("mode", i8Ptr))
        cg.fwriteFunc = cg.module.NewFunc("fwrite", i64,
                ir.NewParam("ptr", i8Ptr),
                ir.NewParam("size", i64),
                ir.NewParam("nmemb", i64),
                ir.NewParam("stream", i8Ptr))
        cg.freadFunc = cg.module.NewFunc("fread", i64,
                ir.NewParam("ptr", i8Ptr),
                ir.NewParam("size", i64),
                ir.NewParam("nmemb", i64),
                ir.NewParam("stream", i8Ptr))
        cg.fcloseFunc = cg.module.NewFunc("fclose", i32, ir.NewParam("stream", i8Ptr))
        cg.fgetsFunc = cg.module.NewFunc("fgets", i8Ptr,
                ir.NewParam("str", i8Ptr),
                ir.NewParam("n", i32),
                ir.NewParam("stream", i8Ptr))
}

func (cg *CodeGen) Generate(program *parser.Program) (string, error) {
        for _, stmt := range program.Statements {
                if fn, ok := stmt.(*parser.FunctionDecl); ok {
                        cg.declareFunction(fn)
                }
                if sd, ok := stmt.(*parser.StructDecl); ok {
                        cg.declareStruct(sd)
                }
        }

        mainStmts := make([]parser.Node, 0)
        for _, stmt := range program.Statements {
                switch s := stmt.(type) {
                case *parser.FunctionDecl:
                        err := cg.generateFunction(s)
                        if err != nil {
                                return "", err
                        }
                case *parser.StructDecl:
                        // already declared
                default:
                        mainStmts = append(mainStmts, s)
                }
        }

        err := cg.generateMain(mainStmts)
        if err != nil {
                return "", err
        }

        return cg.module.String(), nil
}

func (cg *CodeGen) globalString(s string) *ir.Global {
        if g, ok := cg.strings[s]; ok {
                return g
        }

        name := fmt.Sprintf(".str.%d", cg.strCount)
        cg.strCount++

        strVal := constant.NewCharArrayFromString(s + "\x00")
        g := cg.module.NewGlobalDef(name, strVal)
        g.Immutable = true
        cg.strings[s] = g
        return g
}

func (cg *CodeGen) stringPtr(s string) value.Value {
        g := cg.globalString(s)
        return constant.NewGetElementPtr(
                types.NewArray(uint64(len(s)+1), types.I8),
                g,
                constant.NewInt(types.I64, 0),
                constant.NewInt(types.I64, 0),
        )
}

func (cg *CodeGen) declareStruct(sd *parser.StructDecl) {
        fieldTypes := make([]types.Type, len(sd.Fields))
        fieldIndices := make(map[string]int)

        for i, f := range sd.Fields {
                fieldTypes[i] = cg.resolveTypeAnnotation(f.TypeHint)
                fieldIndices[f.Name] = i
        }

        st := types.NewStruct(fieldTypes...)
        st.SetName(sd.Name)
        cg.module.NewTypeDef(sd.Name, st)
        cg.structs[sd.Name] = st
        cg.structFieldIndices[sd.Name] = fieldIndices
}

func (cg *CodeGen) resolveTypeAnnotation(ta *parser.TypeAnnotation) types.Type {
        if ta == nil {
                return types.I64
        }

        if ta.IsArray {
                return types.I8Ptr
        }

        switch ta.Name {
        case "int":
                return types.I64
        case "float":
                return types.Double
        case "string":
                return types.I8Ptr
        case "bool":
                return types.I1
        case "void":
                return types.Void
        default:
                if st, ok := cg.structs[ta.Name]; ok {
                        return types.NewPointer(st)
                }
                return types.I64
        }
}

func (cg *CodeGen) declareFunction(fn *parser.FunctionDecl) {
        params := make([]*ir.Param, len(fn.Params))
        for i, p := range fn.Params {
                paramType := cg.resolveTypeAnnotation(p.TypeHint)
                params[i] = ir.NewParam(p.Name, paramType)
        }

        retType := types.Type(types.Void)
        if fn.ReturnType != nil {
                retType = cg.resolveTypeAnnotation(fn.ReturnType)
        }

        f := cg.module.NewFunc(fn.Name, retType, params...)
        cg.functions[fn.Name] = f
        cg.scope.Set(fn.Name, f)
}

func (cg *CodeGen) generateFunction(fn *parser.FunctionDecl) error {
        f := cg.functions[fn.Name]
        if f == nil {
                return fmt.Errorf("function %s not declared", fn.Name)
        }

        entry := f.NewBlock("entry")

        prevBuilder := cg.builder
        prevFunc := cg.function
        prevScope := cg.scope

        cg.builder = entry
        cg.function = f
        cg.scope = NewCodeGenScope(cg.scope)

        for i, p := range fn.Params {
                alloca := entry.NewAlloca(f.Params[i].Typ)
                entry.NewStore(f.Params[i], alloca)
                cg.scope.Set(p.Name, alloca)
                cg.scope.SetType(p.Name, f.Params[i].Typ)
        }

        hasReturn := false
        for _, stmt := range fn.Body {
                err := cg.generateStatement(stmt)
                if err != nil {
                        return err
                }
                if _, ok := stmt.(*parser.ReturnStatement); ok {
                        hasReturn = true
                }
        }

        if cg.builder.Term == nil {
                if fn.ReturnType == nil || fn.ReturnType.Name == "void" {
                        cg.builder.NewRet(nil)
                } else if !hasReturn {
                        retType := cg.resolveTypeAnnotation(fn.ReturnType)
                        cg.builder.NewRet(constant.NewZeroInitializer(retType))
                }
        }

        cg.builder = prevBuilder
        cg.function = prevFunc
        cg.scope = prevScope

        return nil
}

func (cg *CodeGen) generateMain(stmts []parser.Node) error {
        mainFunc := cg.module.NewFunc("main", types.I32)
        entry := mainFunc.NewBlock("entry")

        cg.builder = entry
        cg.function = mainFunc
        cg.scope = NewCodeGenScope(cg.scope)

        for _, stmt := range stmts {
                err := cg.generateStatement(stmt)
                if err != nil {
                        return err
                }
        }

        if cg.builder.Term == nil {
                cg.builder.NewRet(constant.NewInt(types.I32, 0))
        }

        return nil
}

func (cg *CodeGen) generateStatement(stmt parser.Node) error {
        switch s := stmt.(type) {
        case *parser.LetStatement:
                return cg.generateLetStatement(s)
        case *parser.AssignStatement:
                return cg.generateAssignStatement(s)
        case *parser.ExpressionStatement:
                _, err := cg.generateExpression(s.Expression)
                return err
        case *parser.ReturnStatement:
                return cg.generateReturnStatement(s)
        case *parser.IfStatement:
                return cg.generateIfStatement(s)
        case *parser.WhileStatement:
                return cg.generateWhileStatement(s)
        case *parser.ForStatement:
                return cg.generateForStatement(s)
        case *parser.BreakStatement:
                if cg.breakBlock != nil {
                        cg.builder.NewBr(cg.breakBlock)
                }
                return nil
        case *parser.ContinueStatement:
                if cg.continueBlock != nil {
                        cg.builder.NewBr(cg.continueBlock)
                }
                return nil
        case *parser.ImportStatement:
                return nil
        case *parser.FunctionDecl:
                return cg.generateFunction(s)
        case *parser.StructDecl:
                return nil
        default:
                return fmt.Errorf("unknown statement type: %T", stmt)
        }
}

func (cg *CodeGen) generateLetStatement(s *parser.LetStatement) error {
        val, err := cg.generateExpression(s.Value)
        if err != nil {
                return err
        }

        alloca := cg.builder.NewAlloca(val.Type())
        cg.builder.NewStore(val, alloca)
        cg.scope.Set(s.Name, alloca)
        cg.scope.SetType(s.Name, val.Type())

        return nil
}

func (cg *CodeGen) generateAssignStatement(s *parser.AssignStatement) error {
        val, err := cg.generateExpression(s.Value)
        if err != nil {
                return err
        }

        switch target := s.Target.(type) {
        case *parser.Identifier:
                ptr, ok := cg.scope.Get(target.Name)
                if !ok {
                        return fmt.Errorf("undefined variable: %s", target.Name)
                }
                if s.Op != "=" {
                        current := cg.builder.NewLoad(val.Type(), ptr)
                        switch s.Op {
                        case "+=":
                                if val.Type() == types.Double {
                                        val = cg.builder.NewFAdd(current, val)
                                } else {
                                        val = cg.builder.NewAdd(current, val)
                                }
                        case "-=":
                                if val.Type() == types.Double {
                                        val = cg.builder.NewFSub(current, val)
                                } else {
                                        val = cg.builder.NewSub(current, val)
                                }
                        case "*=":
                                if val.Type() == types.Double {
                                        val = cg.builder.NewFMul(current, val)
                                } else {
                                        val = cg.builder.NewMul(current, val)
                                }
                        case "/=":
                                if val.Type() == types.Double {
                                        val = cg.builder.NewFDiv(current, val)
                                } else {
                                        val = cg.builder.NewSDiv(current, val)
                                }
                        }
                }
                cg.builder.NewStore(val, ptr)
        case *parser.IndexExpr:
                obj, err := cg.generateExpression(target.Object)
                if err != nil {
                        return err
                }
                idx, err := cg.generateExpression(target.Index)
                if err != nil {
                        return err
                }
                gep := cg.builder.NewGetElementPtr(types.I8, obj, idx)
                cg.builder.NewStore(val, gep)
        case *parser.MemberExpr:
                obj, err := cg.generateExpression(target.Object)
                if err != nil {
                        return err
                }
                _ = obj
                _ = target.Member
        }
        return nil
}

func (cg *CodeGen) generateReturnStatement(s *parser.ReturnStatement) error {
        if s.Value == nil {
                cg.builder.NewRet(nil)
                return nil
        }

        val, err := cg.generateExpression(s.Value)
        if err != nil {
                return err
        }

        expectedRetType := cg.function.Sig.RetType
        val = cg.coerceType(val, expectedRetType)

        cg.builder.NewRet(val)
        return nil
}

func (cg *CodeGen) generateIfStatement(s *parser.IfStatement) error {
        cond, err := cg.generateExpression(s.Condition)
        if err != nil {
                return err
        }
        cond = cg.toBool(cond)

        thenBlock := cg.function.NewBlock(cg.tmpName("if.then"))
        var elseBlock *ir.Block
        mergeBlock := cg.function.NewBlock(cg.tmpName("if.merge"))

        if len(s.ElseIfs) > 0 || s.ElseBody != nil {
                elseBlock = cg.function.NewBlock(cg.tmpName("if.else"))
                cg.builder.NewCondBr(cond, thenBlock, elseBlock)
        } else {
                cg.builder.NewCondBr(cond, thenBlock, mergeBlock)
        }

        cg.builder = thenBlock
        cg.scope = NewCodeGenScope(cg.scope)
        for _, stmt := range s.Body {
                err := cg.generateStatement(stmt)
                if err != nil {
                        return err
                }
        }
        cg.scope = cg.scope.parent
        if cg.builder.Term == nil {
                cg.builder.NewBr(mergeBlock)
        }

        if len(s.ElseIfs) > 0 {
                cg.builder = elseBlock
                for i, elif := range s.ElseIfs {
                        elifCond, err := cg.generateExpression(elif.Condition)
                        if err != nil {
                                return err
                        }
                        elifCond = cg.toBool(elifCond)

                        elifThen := cg.function.NewBlock(cg.tmpName("elif.then"))
                        var elifElse *ir.Block

                        if i < len(s.ElseIfs)-1 || s.ElseBody != nil {
                                elifElse = cg.function.NewBlock(cg.tmpName("elif.else"))
                                cg.builder.NewCondBr(elifCond, elifThen, elifElse)
                        } else {
                                cg.builder.NewCondBr(elifCond, elifThen, mergeBlock)
                        }

                        cg.builder = elifThen
                        cg.scope = NewCodeGenScope(cg.scope)
                        for _, stmt := range elif.Body {
                                err := cg.generateStatement(stmt)
                                if err != nil {
                                        return err
                                }
                        }
                        cg.scope = cg.scope.parent
                        if cg.builder.Term == nil {
                                cg.builder.NewBr(mergeBlock)
                        }

                        if elifElse != nil {
                                cg.builder = elifElse
                        }
                }

                if s.ElseBody != nil {
                        cg.scope = NewCodeGenScope(cg.scope)
                        for _, stmt := range s.ElseBody {
                                err := cg.generateStatement(stmt)
                                if err != nil {
                                        return err
                                }
                        }
                        cg.scope = cg.scope.parent
                        if cg.builder.Term == nil {
                                cg.builder.NewBr(mergeBlock)
                        }
                } else if cg.builder.Term == nil {
                        cg.builder.NewBr(mergeBlock)
                }
        } else if s.ElseBody != nil {
                cg.builder = elseBlock
                cg.scope = NewCodeGenScope(cg.scope)
                for _, stmt := range s.ElseBody {
                        err := cg.generateStatement(stmt)
                        if err != nil {
                                return err
                        }
                }
                cg.scope = cg.scope.parent
                if cg.builder.Term == nil {
                        cg.builder.NewBr(mergeBlock)
                }
        }

        cg.builder = mergeBlock
        return nil
}

func (cg *CodeGen) generateWhileStatement(s *parser.WhileStatement) error {
        condBlock := cg.function.NewBlock(cg.tmpName("while.cond"))
        bodyBlock := cg.function.NewBlock(cg.tmpName("while.body"))
        endBlock := cg.function.NewBlock(cg.tmpName("while.end"))

        prevBreak := cg.breakBlock
        prevContinue := cg.continueBlock
        cg.breakBlock = endBlock
        cg.continueBlock = condBlock

        cg.builder.NewBr(condBlock)

        cg.builder = condBlock
        cond, err := cg.generateExpression(s.Condition)
        if err != nil {
                return err
        }
        cond = cg.toBool(cond)
        cg.builder.NewCondBr(cond, bodyBlock, endBlock)

        cg.builder = bodyBlock
        cg.scope = NewCodeGenScope(cg.scope)
        for _, stmt := range s.Body {
                err := cg.generateStatement(stmt)
                if err != nil {
                        return err
                }
        }
        cg.scope = cg.scope.parent
        if cg.builder.Term == nil {
                cg.builder.NewBr(condBlock)
        }

        cg.builder = endBlock
        cg.breakBlock = prevBreak
        cg.continueBlock = prevContinue
        return nil
}

func (cg *CodeGen) generateForStatement(s *parser.ForStatement) error {
        iterVal, err := cg.generateExpression(s.Iterable)
        if err != nil {
                return err
        }

        if rangeExpr, ok := s.Iterable.(*parser.RangeExpr); ok {
                return cg.generateForRange(s, rangeExpr)
        }

        _ = iterVal
        return cg.generateForRange(s, &parser.RangeExpr{
                Start: &parser.IntLiteral{Value: 0},
                End:   &parser.IntLiteral{Value: 10},
        })
}

func (cg *CodeGen) generateForRange(s *parser.ForStatement, r *parser.RangeExpr) error {
        startVal, err := cg.generateExpression(r.Start)
        if err != nil {
                return err
        }
        endVal, err := cg.generateExpression(r.End)
        if err != nil {
                return err
        }

        var stepVal value.Value
        if r.Step != nil {
                stepVal, err = cg.generateExpression(r.Step)
                if err != nil {
                        return err
                }
        } else {
                stepVal = constant.NewInt(types.I64, 1)
        }

        startVal = cg.toI64(startVal)
        endVal = cg.toI64(endVal)
        stepVal = cg.toI64(stepVal)

        iterVar := cg.builder.NewAlloca(types.I64)
        cg.builder.NewStore(startVal, iterVar)

        condBlock := cg.function.NewBlock(cg.tmpName("for.cond"))
        bodyBlock := cg.function.NewBlock(cg.tmpName("for.body"))
        incrBlock := cg.function.NewBlock(cg.tmpName("for.incr"))
        endBlock := cg.function.NewBlock(cg.tmpName("for.end"))

        prevBreak := cg.breakBlock
        prevContinue := cg.continueBlock
        cg.breakBlock = endBlock
        cg.continueBlock = incrBlock

        cg.builder.NewBr(condBlock)

        cg.builder = condBlock
        currentVal := cg.builder.NewLoad(types.I64, iterVar)
        cond := cg.builder.NewICmp(enum.IPredSLT, currentVal, endVal)
        cg.builder.NewCondBr(cond, bodyBlock, endBlock)

        cg.builder = bodyBlock
        cg.scope = NewCodeGenScope(cg.scope)
        cg.scope.Set(s.Variable, iterVar)
        cg.scope.SetType(s.Variable, types.I64)

        for _, stmt := range s.Body {
                err := cg.generateStatement(stmt)
                if err != nil {
                        return err
                }
        }
        cg.scope = cg.scope.parent
        if cg.builder.Term == nil {
                cg.builder.NewBr(incrBlock)
        }

        cg.builder = incrBlock
        cur := cg.builder.NewLoad(types.I64, iterVar)
        next := cg.builder.NewAdd(cur, stepVal)
        cg.builder.NewStore(next, iterVar)
        cg.builder.NewBr(condBlock)

        cg.builder = endBlock
        cg.breakBlock = prevBreak
        cg.continueBlock = prevContinue
        return nil
}

func (cg *CodeGen) generateExpression(expr parser.Node) (value.Value, error) {
        switch e := expr.(type) {
        case *parser.IntLiteral:
                return constant.NewInt(types.I64, e.Value), nil

        case *parser.FloatLiteral:
                return constant.NewFloat(types.Double, e.Value), nil

        case *parser.StringLiteral:
                return cg.stringPtr(e.Value), nil

        case *parser.BoolLiteral:
                if e.Value {
                        return constant.NewInt(types.I1, 1), nil
                }
                return constant.NewInt(types.I1, 0), nil

        case *parser.NilLiteral:
                return constant.NewNull(types.I8Ptr), nil

        case *parser.Identifier:
                return cg.generateIdentifier(e)

        case *parser.BinaryExpr:
                return cg.generateBinaryExpr(e)

        case *parser.UnaryExpr:
                return cg.generateUnaryExpr(e)

        case *parser.CallExpr:
                return cg.generateCallExpr(e)

        case *parser.IndexExpr:
                return cg.generateIndexExpr(e)

        case *parser.MemberExpr:
                return cg.generateMemberExpr(e)

        case *parser.ArrayLiteral:
                return cg.generateArrayLiteral(e)

        case *parser.RangeExpr:
                return constant.NewInt(types.I64, 0), nil

        default:
                return nil, fmt.Errorf("unknown expression type: %T", expr)
        }
}

func (cg *CodeGen) generateIdentifier(id *parser.Identifier) (value.Value, error) {
        ptr, ok := cg.scope.Get(id.Name)
        if !ok {
                if fn, ok := cg.functions[id.Name]; ok {
                        return fn, nil
                }
                return nil, fmt.Errorf("undefined variable: %s", id.Name)
        }

        if alloca, ok := ptr.(*ir.InstAlloca); ok {
                return cg.builder.NewLoad(alloca.ElemType, ptr), nil
        }

        return ptr, nil
}

func (cg *CodeGen) generateBinaryExpr(e *parser.BinaryExpr) (value.Value, error) {
        left, err := cg.generateExpression(e.Left)
        if err != nil {
                return nil, err
        }
        right, err := cg.generateExpression(e.Right)
        if err != nil {
                return nil, err
        }

        if e.Operator == ".." {
                return cg.generateStringConcat(left, right)
        }

        isFloat := left.Type() == types.Double || right.Type() == types.Double
        isString := cg.isStringType(left.Type()) || cg.isStringType(right.Type())

        if isFloat {
                left = cg.toDouble(left)
                right = cg.toDouble(right)
        } else if !isString {
                left = cg.toI64(left)
                right = cg.toI64(right)
        }

        switch e.Operator {
        case "+":
                if isFloat {
                        return cg.builder.NewFAdd(left, right), nil
                }
                return cg.builder.NewAdd(left, right), nil
        case "-":
                if isFloat {
                        return cg.builder.NewFSub(left, right), nil
                }
                return cg.builder.NewSub(left, right), nil
        case "*":
                if isFloat {
                        return cg.builder.NewFMul(left, right), nil
                }
                return cg.builder.NewMul(left, right), nil
        case "/":
                if isFloat {
                        return cg.builder.NewFDiv(left, right), nil
                }
                return cg.builder.NewSDiv(left, right), nil
        case "%":
                return cg.builder.NewSRem(left, right), nil
        case "==":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredOEQ, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredEQ, left, right), nil
        case "!=":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredONE, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredNE, left, right), nil
        case "<":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredOLT, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredSLT, left, right), nil
        case ">":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredOGT, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredSGT, left, right), nil
        case "<=":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredOLE, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredSLE, left, right), nil
        case ">=":
                if isFloat {
                        return cg.builder.NewFCmp(enum.FPredOGE, left, right), nil
                }
                return cg.builder.NewICmp(enum.IPredSGE, left, right), nil
        case "and":
                leftBool := cg.toBool(left)
                rightBool := cg.toBool(right)
                return cg.builder.NewAnd(leftBool, rightBool), nil
        case "or":
                leftBool := cg.toBool(left)
                rightBool := cg.toBool(right)
                return cg.builder.NewOr(leftBool, rightBool), nil
        default:
                return nil, fmt.Errorf("unknown operator: %s", e.Operator)
        }
}

func (cg *CodeGen) generateUnaryExpr(e *parser.UnaryExpr) (value.Value, error) {
        operand, err := cg.generateExpression(e.Operand)
        if err != nil {
                return nil, err
        }

        switch e.Operator {
        case "-":
                if operand.Type() == types.Double {
                        return cg.builder.NewFNeg(operand), nil
                }
                return cg.builder.NewSub(constant.NewInt(types.I64, 0), operand), nil
        case "not":
                boolVal := cg.toBool(operand)
                return cg.builder.NewXor(boolVal, constant.NewInt(types.I1, 1)), nil
        default:
                return nil, fmt.Errorf("unknown unary operator: %s", e.Operator)
        }
}

func (cg *CodeGen) generateCallExpr(e *parser.CallExpr) (value.Value, error) {
        if ident, ok := e.Callee.(*parser.Identifier); ok {
                switch ident.Name {
                case "print":
                        return cg.generatePrint(e.Args, false)
                case "println":
                        return cg.generatePrint(e.Args, true)
                case "len":
                        return cg.generateLen(e.Args)
                case "str", "tostring":
                        return cg.generateToString(e.Args)
                case "int", "tonumber":
                        return cg.generateToInt(e.Args)
                case "float":
                        return cg.generateToFloat(e.Args)
                case "input":
                        return cg.generateInput(e.Args)
                case "exit":
                        return cg.generateExit(e.Args)
                case "range":
                        return constant.NewInt(types.I64, 0), nil
                }
        }

        if member, ok := e.Callee.(*parser.MemberExpr); ok {
                return cg.generateMethodCall(member, e.Args)
        }

        callee, err := cg.generateExpression(e.Callee)
        if err != nil {
                return nil, err
        }

        fn, ok := callee.(*ir.Func)
        if !ok {
                return nil, fmt.Errorf("not a callable")
        }

        args := make([]value.Value, len(e.Args))
        for i, arg := range e.Args {
                argVal, err := cg.generateExpression(arg)
                if err != nil {
                        return nil, err
                }
                if i < len(fn.Params) {
                        argVal = cg.coerceType(argVal, fn.Params[i].Typ)
                }
                args[i] = argVal
        }

        result := cg.builder.NewCall(fn, args...)
        return result, nil
}

func (cg *CodeGen) generateMethodCall(member *parser.MemberExpr, args []parser.Node) (value.Value, error) {
        obj, err := cg.generateExpression(member.Object)
        if err != nil {
                return nil, err
        }

        switch member.Member {
        case "push", "append":
                if len(args) > 0 {
                        _, err := cg.generateExpression(args[0])
                        if err != nil {
                                return nil, err
                        }
                }
                return obj, nil
        case "len":
                if cg.isStringType(obj.Type()) {
                        return cg.builder.NewCall(cg.strlenFunc, obj), nil
                }
                return constant.NewInt(types.I64, 0), nil
        }

        return obj, nil
}

func (cg *CodeGen) generatePrint(args []parser.Node, newline bool) (value.Value, error) {
        if len(args) == 0 {
                if newline {
                        fmtStr := cg.stringPtr("\n")
                        return cg.builder.NewCall(cg.printfFunc, fmtStr), nil
                }
                return constant.NewInt(types.I32, 0), nil
        }

        for i, arg := range args {
                if i > 0 {
                        spaceStr := cg.stringPtr(" ")
                        cg.builder.NewCall(cg.printfFunc, spaceStr)
                }

                val, err := cg.generateExpression(arg)
                if err != nil {
                        return nil, err
                }

                switch {
                case val.Type() == types.I64:
                        fmtStr := cg.stringPtr("%ld")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, val)
                case val.Type() == types.Double:
                        fmtStr := cg.stringPtr("%g")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, val)
                case val.Type() == types.I1:
                        trueStr := cg.stringPtr("true")
                        falseStr := cg.stringPtr("false")
                        selected := cg.builder.NewSelect(val, trueStr, falseStr)
                        fmtStr := cg.stringPtr("%s")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, selected)
                case val.Type() == types.I32:
                        fmtStr := cg.stringPtr("%d")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, val)
                case cg.isStringType(val.Type()):
                        fmtStr := cg.stringPtr("%s")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, val)
                default:
                        fmtStr := cg.stringPtr("%ld")
                        cg.builder.NewCall(cg.printfFunc, fmtStr, val)
                }
        }

        if newline {
                nlStr := cg.stringPtr("\n")
                cg.builder.NewCall(cg.printfFunc, nlStr)
        }

        return constant.NewInt(types.I32, 0), nil
}

func (cg *CodeGen) generateLen(args []parser.Node) (value.Value, error) {
        if len(args) != 1 {
                return nil, fmt.Errorf("len() requires exactly 1 argument")
        }

        val, err := cg.generateExpression(args[0])
        if err != nil {
                return nil, err
        }

        if cg.isStringType(val.Type()) {
                result := cg.builder.NewCall(cg.strlenFunc, val)
                return result, nil
        }

        return constant.NewInt(types.I64, 0), nil
}

func (cg *CodeGen) generateToString(args []parser.Node) (value.Value, error) {
        if len(args) != 1 {
                return nil, fmt.Errorf("str() requires exactly 1 argument")
        }

        val, err := cg.generateExpression(args[0])
        if err != nil {
                return nil, err
        }

        if cg.isStringType(val.Type()) {
                return val, nil
        }

        buf := cg.builder.NewCall(cg.mallocFunc, constant.NewInt(types.I64, 64))
        if val.Type() == types.I64 {
                fmtStr := cg.stringPtr("%ld")
                cg.builder.NewCall(cg.sprintfFunc, buf, fmtStr, val)
        } else if val.Type() == types.Double {
                fmtStr := cg.stringPtr("%g")
                cg.builder.NewCall(cg.sprintfFunc, buf, fmtStr, val)
        } else if val.Type() == types.I1 {
                trueStr := cg.stringPtr("true")
                falseStr := cg.stringPtr("false")
                src := cg.builder.NewSelect(val, trueStr, falseStr)
                cg.builder.NewCall(cg.strcpyFunc, buf, src)
        } else {
                fmtStr := cg.stringPtr("%ld")
                cg.builder.NewCall(cg.sprintfFunc, buf, fmtStr, val)
        }

        return buf, nil
}

func (cg *CodeGen) generateToInt(args []parser.Node) (value.Value, error) {
        if len(args) != 1 {
                return nil, fmt.Errorf("int() requires exactly 1 argument")
        }

        val, err := cg.generateExpression(args[0])
        if err != nil {
                return nil, err
        }

        if val.Type() == types.I64 {
                return val, nil
        }
        if val.Type() == types.Double {
                return cg.builder.NewFPToSI(val, types.I64), nil
        }
        if cg.isStringType(val.Type()) {
                i32Val := cg.builder.NewCall(cg.atoiFunc, val)
                return cg.builder.NewSExt(i32Val, types.I64), nil
        }
        if val.Type() == types.I1 {
                return cg.builder.NewZExt(val, types.I64), nil
        }

        return cg.toI64(val), nil
}

func (cg *CodeGen) generateToFloat(args []parser.Node) (value.Value, error) {
        if len(args) != 1 {
                return nil, fmt.Errorf("float() requires exactly 1 argument")
        }

        val, err := cg.generateExpression(args[0])
        if err != nil {
                return nil, err
        }

        return cg.toDouble(val), nil
}

func (cg *CodeGen) generateInput(args []parser.Node) (value.Value, error) {
        if len(args) > 0 {
                cg.generatePrint(args, false)
        }

        bufSize := constant.NewInt(types.I64, 1024)
        buf := cg.builder.NewCall(cg.mallocFunc, bufSize)

        linePtrAlloca := cg.builder.NewAlloca(types.I8Ptr)
        cg.builder.NewStore(buf, linePtrAlloca)
        nAlloca := cg.builder.NewAlloca(types.I64)
        cg.builder.NewStore(bufSize, nAlloca)

        stdinVal := cg.builder.NewLoad(types.I8Ptr, cg.stdinGlobal)
        nread := cg.builder.NewCall(cg.getlineFunc, linePtrAlloca, nAlloca, stdinVal)

        isPositive := cg.builder.NewICmp(enum.IPredSGT, nread, constant.NewInt(types.I64, 0))

        resultBuf := cg.builder.NewLoad(types.I8Ptr, linePtrAlloca)

        stripBlock := cg.function.NewBlock(cg.tmpName("input.strip"))
        doneBlock := cg.function.NewBlock(cg.tmpName("input.done"))

        cg.builder.NewCondBr(isPositive, stripBlock, doneBlock)

        cg.builder = stripBlock
        lastIdx := cg.builder.NewSub(nread, constant.NewInt(types.I64, 1))
        lastCharPtr := cg.builder.NewGetElementPtr(types.I8, resultBuf, lastIdx)
        lastChar := cg.builder.NewLoad(types.I8, lastCharPtr)
        isNewline := cg.builder.NewICmp(enum.IPredEQ, lastChar, constant.NewInt(types.I8, 10))

        stripNlBlock := cg.function.NewBlock(cg.tmpName("input.stripnl"))
        cg.builder.NewCondBr(isNewline, stripNlBlock, doneBlock)

        cg.builder = stripNlBlock
        cg.builder.NewStore(constant.NewInt(types.I8, 0), lastCharPtr)
        cg.builder.NewBr(doneBlock)

        cg.builder = doneBlock
        return resultBuf, nil
}

func (cg *CodeGen) generateExit(args []parser.Node) (value.Value, error) {
        var exitCode value.Value = constant.NewInt(types.I32, 0)
        if len(args) > 0 {
                val, err := cg.generateExpression(args[0])
                if err != nil {
                        return nil, err
                }
                if val.Type() == types.I64 {
                        exitCode = cg.builder.NewTrunc(val, types.I32)
                } else if val.Type() == types.I32 {
                        exitCode = val
                } else {
                        exitCode = cg.builder.NewTrunc(cg.toI64(val), types.I32)
                }
        }

        cg.builder.NewCall(cg.exitFunc, exitCode)
        cg.builder.NewUnreachable()
        return constant.NewInt(types.I32, 0), nil
}

func (cg *CodeGen) generateIndexExpr(e *parser.IndexExpr) (value.Value, error) {
        obj, err := cg.generateExpression(e.Object)
        if err != nil {
                return nil, err
        }
        idx, err := cg.generateExpression(e.Index)
        if err != nil {
                return nil, err
        }

        if cg.isStringType(obj.Type()) {
                charPtr := cg.builder.NewGetElementPtr(types.I8, obj, idx)
                charVal := cg.builder.NewLoad(types.I8, charPtr)
                return cg.builder.NewZExt(charVal, types.I64), nil
        }

        _ = idx
        return constant.NewInt(types.I64, 0), nil
}

func (cg *CodeGen) generateMemberExpr(e *parser.MemberExpr) (value.Value, error) {
        obj, err := cg.generateExpression(e.Object)
        if err != nil {
                return nil, err
        }

        _ = obj
        return constant.NewInt(types.I64, 0), nil
}

func (cg *CodeGen) generateArrayLiteral(e *parser.ArrayLiteral) (value.Value, error) {
        if len(e.Elements) == 0 {
                return constant.NewNull(types.I8Ptr), nil
        }

        elemSize := constant.NewInt(types.I64, 8)
        totalSize := constant.NewInt(types.I64, int64(len(e.Elements)*8))
        buf := cg.builder.NewCall(cg.mallocFunc, totalSize)

        for i, elem := range e.Elements {
                val, err := cg.generateExpression(elem)
                if err != nil {
                        return nil, err
                }
                val = cg.toI64(val)
                offset := cg.builder.NewMul(constant.NewInt(types.I64, int64(i)), elemSize)
                ptr := cg.builder.NewGetElementPtr(types.I8, buf, offset)
                i64Ptr := cg.builder.NewBitCast(ptr, types.NewPointer(types.I64))
                cg.builder.NewStore(val, i64Ptr)
        }

        return buf, nil
}

func (cg *CodeGen) generateStringConcat(left, right value.Value) (value.Value, error) {
        leftStr := left
        rightStr := right

        if !cg.isStringType(left.Type()) {
                leftStr2, err := cg.generateToString([]parser.Node{})
                if err != nil {
                        return nil, err
                }
                leftStr = leftStr2
        }
        if !cg.isStringType(right.Type()) {
                rightStr2, err := cg.generateToString([]parser.Node{})
                if err != nil {
                        return nil, err
                }
                rightStr = rightStr2
        }

        leftLen := cg.builder.NewCall(cg.strlenFunc, leftStr)
        rightLen := cg.builder.NewCall(cg.strlenFunc, rightStr)
        totalLen := cg.builder.NewAdd(leftLen, rightLen)
        totalLen = cg.builder.NewAdd(totalLen, constant.NewInt(types.I64, 1))

        buf := cg.builder.NewCall(cg.mallocFunc, totalLen)
        cg.builder.NewCall(cg.strcpyFunc, buf, leftStr)
        cg.builder.NewCall(cg.strcatFunc, buf, rightStr)

        return buf, nil
}

func (cg *CodeGen) toBool(val value.Value) value.Value {
        switch val.Type() {
        case types.I1:
                return val
        case types.I64:
                return cg.builder.NewICmp(enum.IPredNE, val, constant.NewInt(types.I64, 0))
        case types.I32:
                return cg.builder.NewICmp(enum.IPredNE, val, constant.NewInt(types.I32, 0))
        case types.Double:
                return cg.builder.NewFCmp(enum.FPredONE, val, constant.NewFloat(types.Double, 0.0))
        default:
                return cg.builder.NewICmp(enum.IPredNE,
                        cg.builder.NewPtrToInt(val, types.I64),
                        constant.NewInt(types.I64, 0))
        }
}

func (cg *CodeGen) toI64(val value.Value) value.Value {
        switch val.Type() {
        case types.I64:
                return val
        case types.I32:
                return cg.builder.NewSExt(val, types.I64)
        case types.I1:
                return cg.builder.NewZExt(val, types.I64)
        case types.Double:
                return cg.builder.NewFPToSI(val, types.I64)
        case types.I8:
                return cg.builder.NewSExt(val, types.I64)
        default:
                return cg.builder.NewPtrToInt(val, types.I64)
        }
}

func (cg *CodeGen) toDouble(val value.Value) value.Value {
        switch val.Type() {
        case types.Double:
                return val
        case types.I64:
                return cg.builder.NewSIToFP(val, types.Double)
        case types.I32:
                return cg.builder.NewSIToFP(val, types.Double)
        case types.I1:
                ext := cg.builder.NewZExt(val, types.I64)
                return cg.builder.NewSIToFP(ext, types.Double)
        default:
                return val
        }
}

func (cg *CodeGen) coerceType(val value.Value, target types.Type) value.Value {
        if val.Type() == target {
                return val
        }

        switch target {
        case types.I64:
                return cg.toI64(val)
        case types.Double:
                return cg.toDouble(val)
        case types.I1:
                return cg.toBool(val)
        case types.I32:
                if val.Type() == types.I64 {
                        return cg.builder.NewTrunc(val, types.I32)
                }
                return cg.toI64(val)
        default:
                return val
        }
}

func (cg *CodeGen) isStringType(t types.Type) bool {
        if t == types.I8Ptr {
                return true
        }
        if pt, ok := t.(*types.PointerType); ok {
                if pt.ElemType == types.I8 {
                        return true
                }
        }
        return false
}

func (cg *CodeGen) tmpName(prefix string) string {
        cg.tmpCount++
        return fmt.Sprintf("%s.%d", prefix, cg.tmpCount)
}
