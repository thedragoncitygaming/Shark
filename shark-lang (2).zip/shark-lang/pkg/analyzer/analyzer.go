package analyzer

import (
	"fmt"
	"shark-lang/pkg/parser"
)

type SharkType int

const (
	TypeUnknown SharkType = iota
	TypeInt
	TypeFloat
	TypeString
	TypeBool
	TypeVoid
	TypeNil
	TypeArray
	TypeStruct
	TypeFunction
)

func (t SharkType) String() string {
	names := map[SharkType]string{
		TypeUnknown:  "unknown",
		TypeInt:      "int",
		TypeFloat:    "float",
		TypeString:   "string",
		TypeBool:     "bool",
		TypeVoid:     "void",
		TypeNil:      "nil",
		TypeArray:    "array",
		TypeStruct:   "struct",
		TypeFunction: "function",
	}
	if name, ok := names[t]; ok {
		return name
	}
	return "unknown"
}

type TypeInfo struct {
	Type     SharkType
	ElemType *TypeInfo
	Name     string
	Params   []TypeInfo
	Return   *TypeInfo
	Fields   map[string]*TypeInfo
}

type Symbol struct {
	Name    string
	Type    *TypeInfo
	IsConst bool
	IsFn    bool
}

type Scope struct {
	parent  *Scope
	symbols map[string]*Symbol
}

func NewScope(parent *Scope) *Scope {
	return &Scope{
		parent:  parent,
		symbols: make(map[string]*Symbol),
	}
}

func (s *Scope) Define(name string, sym *Symbol) error {
	if _, exists := s.symbols[name]; exists {
		return fmt.Errorf("symbol '%s' already defined in this scope", name)
	}
	s.symbols[name] = sym
	return nil
}

func (s *Scope) Lookup(name string) *Symbol {
	if sym, ok := s.symbols[name]; ok {
		return sym
	}
	if s.parent != nil {
		return s.parent.Lookup(name)
	}
	return nil
}

type StructDef struct {
	Name   string
	Fields []parser.StructField
}

type Analyzer struct {
	scope      *Scope
	errors     []string
	structs    map[string]*StructDef
	functions  map[string]*parser.FunctionDecl
	inFunction bool
	inLoop     bool
}

func New() *Analyzer {
	a := &Analyzer{
		scope:     NewScope(nil),
		errors:    make([]string, 0),
		structs:   make(map[string]*StructDef),
		functions: make(map[string]*parser.FunctionDecl),
	}
	a.defineBuiltins()
	return a
}

func (a *Analyzer) defineBuiltins() {
	builtins := []struct {
		name string
		typ  *TypeInfo
	}{
		{"print", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeVoid}}},
		{"println", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeVoid}}},
		{"len", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeInt}}},
		{"str", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeString}}},
		{"int", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeInt}}},
		{"float", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeFloat}}},
		{"input", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeString}}},
		{"exit", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeVoid}}},
		{"typeof", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeString}}},
		{"append", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeArray}}},
		{"tostring", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeString}}},
		{"tonumber", &TypeInfo{Type: TypeFunction, Return: &TypeInfo{Type: TypeFloat}}},
	}

	for _, b := range builtins {
		a.scope.Define(b.name, &Symbol{Name: b.name, Type: b.typ, IsFn: true})
	}
}

func (a *Analyzer) Analyze(program *parser.Program) []string {
	for _, stmt := range program.Statements {
		a.analyzeNode(stmt)
	}
	return a.errors
}

func (a *Analyzer) addError(line int, msg string) {
	a.errors = append(a.errors, fmt.Sprintf("line %d: %s", line, msg))
}

func (a *Analyzer) resolveType(ta *parser.TypeAnnotation) *TypeInfo {
	if ta == nil {
		return &TypeInfo{Type: TypeUnknown}
	}

	if ta.IsArray {
		elemType := a.resolveType(ta.ElemType)
		return &TypeInfo{Type: TypeArray, ElemType: elemType}
	}

	switch ta.Name {
	case "int":
		return &TypeInfo{Type: TypeInt}
	case "float":
		return &TypeInfo{Type: TypeFloat}
	case "string":
		return &TypeInfo{Type: TypeString}
	case "bool":
		return &TypeInfo{Type: TypeBool}
	case "void":
		return &TypeInfo{Type: TypeVoid}
	default:
		if _, ok := a.structs[ta.Name]; ok {
			return &TypeInfo{Type: TypeStruct, Name: ta.Name}
		}
		return &TypeInfo{Type: TypeUnknown, Name: ta.Name}
	}
}

func (a *Analyzer) analyzeNode(node parser.Node) *TypeInfo {
	switch n := node.(type) {
	case *parser.LetStatement:
		return a.analyzeLetStatement(n)
	case *parser.AssignStatement:
		return a.analyzeAssignStatement(n)
	case *parser.FunctionDecl:
		return a.analyzeFunctionDecl(n)
	case *parser.ReturnStatement:
		return a.analyzeReturnStatement(n)
	case *parser.IfStatement:
		return a.analyzeIfStatement(n)
	case *parser.WhileStatement:
		return a.analyzeWhileStatement(n)
	case *parser.ForStatement:
		return a.analyzeForStatement(n)
	case *parser.BreakStatement:
		if !a.inLoop {
			a.addError(n.Line, "break statement outside of loop")
		}
		return nil
	case *parser.ContinueStatement:
		if !a.inLoop {
			a.addError(n.Line, "continue statement outside of loop")
		}
		return nil
	case *parser.ImportStatement:
		return nil
	case *parser.StructDecl:
		return a.analyzeStructDecl(n)
	case *parser.ExpressionStatement:
		return a.analyzeNode(n.Expression)
	case *parser.BinaryExpr:
		return a.analyzeBinaryExpr(n)
	case *parser.UnaryExpr:
		return a.analyzeUnaryExpr(n)
	case *parser.CallExpr:
		return a.analyzeCallExpr(n)
	case *parser.IndexExpr:
		a.analyzeNode(n.Object)
		a.analyzeNode(n.Index)
		return &TypeInfo{Type: TypeUnknown}
	case *parser.MemberExpr:
		a.analyzeNode(n.Object)
		return &TypeInfo{Type: TypeUnknown}
	case *parser.IntLiteral:
		return &TypeInfo{Type: TypeInt}
	case *parser.FloatLiteral:
		return &TypeInfo{Type: TypeFloat}
	case *parser.StringLiteral:
		return &TypeInfo{Type: TypeString}
	case *parser.BoolLiteral:
		return &TypeInfo{Type: TypeBool}
	case *parser.NilLiteral:
		return &TypeInfo{Type: TypeNil}
	case *parser.Identifier:
		sym := a.scope.Lookup(n.Name)
		if sym == nil {
			a.addError(n.Line, fmt.Sprintf("undefined variable '%s'", n.Name))
			return &TypeInfo{Type: TypeUnknown}
		}
		return sym.Type
	case *parser.ArrayLiteral:
		for _, elem := range n.Elements {
			a.analyzeNode(elem)
		}
		return &TypeInfo{Type: TypeArray}
	case *parser.RangeExpr:
		a.analyzeNode(n.Start)
		a.analyzeNode(n.End)
		if n.Step != nil {
			a.analyzeNode(n.Step)
		}
		return &TypeInfo{Type: TypeArray, ElemType: &TypeInfo{Type: TypeInt}}
	default:
		return &TypeInfo{Type: TypeUnknown}
	}
}

func (a *Analyzer) analyzeLetStatement(n *parser.LetStatement) *TypeInfo {
	valueType := a.analyzeNode(n.Value)
	if n.TypeHint != nil {
		a.resolveType(n.TypeHint)
	}

	sym := &Symbol{Name: n.Name, Type: valueType, IsConst: n.IsConst}
	err := a.scope.Define(n.Name, sym)
	if err != nil {
		a.addError(n.Line, err.Error())
	}
	return nil
}

func (a *Analyzer) analyzeAssignStatement(n *parser.AssignStatement) *TypeInfo {
	a.analyzeNode(n.Value)

	if ident, ok := n.Target.(*parser.Identifier); ok {
		sym := a.scope.Lookup(ident.Name)
		if sym == nil {
			a.addError(n.Line, fmt.Sprintf("undefined variable '%s'", ident.Name))
		} else if sym.IsConst {
			a.addError(n.Line, fmt.Sprintf("cannot assign to const '%s'", ident.Name))
		}
	} else {
		a.analyzeNode(n.Target)
	}
	return nil
}

func (a *Analyzer) analyzeFunctionDecl(n *parser.FunctionDecl) *TypeInfo {
	a.functions[n.Name] = n

	retType := a.resolveType(n.ReturnType)
	paramTypes := make([]TypeInfo, len(n.Params))
	for i, p := range n.Params {
		paramTypes[i] = *a.resolveType(p.TypeHint)
	}

	fnType := &TypeInfo{
		Type:   TypeFunction,
		Params: paramTypes,
		Return: retType,
	}

	a.scope.Define(n.Name, &Symbol{Name: n.Name, Type: fnType, IsFn: true})

	prevInFunction := a.inFunction
	a.inFunction = true

	a.scope = NewScope(a.scope)
	for i, p := range n.Params {
		a.scope.Define(p.Name, &Symbol{Name: p.Name, Type: &paramTypes[i]})
	}

	for _, stmt := range n.Body {
		a.analyzeNode(stmt)
	}

	a.scope = a.scope.parent
	a.inFunction = prevInFunction
	return nil
}

func (a *Analyzer) analyzeReturnStatement(n *parser.ReturnStatement) *TypeInfo {
	if !a.inFunction {
		a.addError(n.Line, "return statement outside of function")
	}
	if n.Value != nil {
		a.analyzeNode(n.Value)
	}
	return nil
}

func (a *Analyzer) analyzeIfStatement(n *parser.IfStatement) *TypeInfo {
	a.analyzeNode(n.Condition)

	a.scope = NewScope(a.scope)
	for _, stmt := range n.Body {
		a.analyzeNode(stmt)
	}
	a.scope = a.scope.parent

	for _, elif := range n.ElseIfs {
		a.analyzeNode(elif.Condition)
		a.scope = NewScope(a.scope)
		for _, stmt := range elif.Body {
			a.analyzeNode(stmt)
		}
		a.scope = a.scope.parent
	}

	if n.ElseBody != nil {
		a.scope = NewScope(a.scope)
		for _, stmt := range n.ElseBody {
			a.analyzeNode(stmt)
		}
		a.scope = a.scope.parent
	}
	return nil
}

func (a *Analyzer) analyzeWhileStatement(n *parser.WhileStatement) *TypeInfo {
	a.analyzeNode(n.Condition)

	prevInLoop := a.inLoop
	a.inLoop = true

	a.scope = NewScope(a.scope)
	for _, stmt := range n.Body {
		a.analyzeNode(stmt)
	}
	a.scope = a.scope.parent

	a.inLoop = prevInLoop
	return nil
}

func (a *Analyzer) analyzeForStatement(n *parser.ForStatement) *TypeInfo {
	a.analyzeNode(n.Iterable)

	prevInLoop := a.inLoop
	a.inLoop = true

	a.scope = NewScope(a.scope)
	a.scope.Define(n.Variable, &Symbol{Name: n.Variable, Type: &TypeInfo{Type: TypeUnknown}})

	for _, stmt := range n.Body {
		a.analyzeNode(stmt)
	}
	a.scope = a.scope.parent

	a.inLoop = prevInLoop
	return nil
}

func (a *Analyzer) analyzeStructDecl(n *parser.StructDecl) *TypeInfo {
	a.structs[n.Name] = &StructDef{Name: n.Name, Fields: n.Fields}
	return nil
}

func (a *Analyzer) analyzeBinaryExpr(n *parser.BinaryExpr) *TypeInfo {
	leftType := a.analyzeNode(n.Left)
	rightType := a.analyzeNode(n.Right)

	switch n.Operator {
	case "+", "-", "*", "/", "%":
		if leftType != nil && rightType != nil {
			if leftType.Type == TypeFloat || rightType.Type == TypeFloat {
				return &TypeInfo{Type: TypeFloat}
			}
			return &TypeInfo{Type: TypeInt}
		}
	case "==", "!=", "<", ">", "<=", ">=":
		return &TypeInfo{Type: TypeBool}
	case "and", "or":
		return &TypeInfo{Type: TypeBool}
	case "..":
		return &TypeInfo{Type: TypeString}
	}

	return &TypeInfo{Type: TypeUnknown}
}

func (a *Analyzer) analyzeUnaryExpr(n *parser.UnaryExpr) *TypeInfo {
	operandType := a.analyzeNode(n.Operand)

	switch n.Operator {
	case "-":
		return operandType
	case "not":
		return &TypeInfo{Type: TypeBool}
	}

	return &TypeInfo{Type: TypeUnknown}
}

func (a *Analyzer) analyzeCallExpr(n *parser.CallExpr) *TypeInfo {
	calleeType := a.analyzeNode(n.Callee)

	for _, arg := range n.Args {
		a.analyzeNode(arg)
	}

	if calleeType != nil && calleeType.Return != nil {
		return calleeType.Return
	}

	return &TypeInfo{Type: TypeUnknown}
}
