package main

import (
	"os/exec"
	"syscall"
)

type exitError struct {
	code int
}

func (e *exitError) Error() string {
	return "exit"
}

func createExecCommand(path string) *exec.Cmd {
	return exec.Command(path)
}

func getExitCode(err error) int {
	if exitErr, ok := err.(*exec.ExitError); ok {
		if status, ok := exitErr.Sys().(syscall.WaitStatus); ok {
			return status.ExitStatus()
		}
	}
	return 1
}
