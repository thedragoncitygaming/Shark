package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"shark-lang/pkg/analyzer"
	"shark-lang/pkg/codegen"
	"shark-lang/pkg/lexer"
	"shark-lang/pkg/linker"
	"shark-lang/pkg/parser"
	"shark-lang/pkg/pkgmanager"
)

const version = "0.1.0"

func printUsage() {
	fmt.Println("Shark Programming Language v" + version)
	fmt.Println()
	fmt.Println("Usage:")
	fmt.Println("  shark <file.shk>              Compile to a.out")
	fmt.Println("  shark <file.shk> -o <output>  Compile to named executable")
	fmt.Println("  shark run <file.shk>          Compile and run immediately")
	fmt.Println("  shark build <file.shk>        Same as shark <file.shk>")
	fmt.Println("  shark install <url>           Install a package from URL")
	fmt.Println("  shark uninstall <name>        Uninstall a package")
	fmt.Println("  shark list                    List installed packages")
	fmt.Println("  shark version                 Show version")
	fmt.Println("  shark help                    Show this help")
	fmt.Println()
	fmt.Println("Options:")
	fmt.Println("  -o <file>     Output file name")
	fmt.Println("  -v            Verbose output")
	fmt.Println("  --emit-ir     Output LLVM IR instead of compiling")
	fmt.Println("  --ast         Print AST (for debugging)")
	fmt.Println("  --tokens      Print tokens (for debugging)")
	fmt.Println()
	fmt.Println("Examples:")
	fmt.Println("  shark hello.shk               # produces a.out")
	fmt.Println("  shark hello.shk -o hello      # produces hello")
	fmt.Println("  shark run hello.shk           # compile and run")
	fmt.Println("  shark install https://example.com/lib.tar.gz")
}

func main() {
	args := os.Args[1:]

	if len(args) == 0 {
		printUsage()
		os.Exit(0)
	}

	verbose := false
	emitIR := false
	printAST := false
	printTokens := false
	outputFile := ""
	inputFile := ""
	command := ""
	pkgURL := ""
	pkgName := ""

	i := 0
	for i < len(args) {
		arg := args[i]

		switch {
		case arg == "-v" || arg == "--verbose":
			verbose = true
		case arg == "--emit-ir":
			emitIR = true
		case arg == "--ast":
			printAST = true
		case arg == "--tokens":
			printTokens = true
		case arg == "-o":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "error: -o requires an argument")
				os.Exit(1)
			}
			outputFile = args[i]
		case arg == "-h" || arg == "--help" || arg == "help":
			printUsage()
			os.Exit(0)
		case arg == "version" || arg == "--version":
			fmt.Println("Shark v" + version)
			os.Exit(0)
		case arg == "run":
			command = "run"
		case arg == "build":
			command = "build"
		case arg == "install":
			command = "install"
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "error: install requires a URL argument")
				os.Exit(1)
			}
			pkgURL = args[i]
		case arg == "uninstall":
			command = "uninstall"
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "error: uninstall requires a package name")
				os.Exit(1)
			}
			pkgName = args[i]
		case arg == "list":
			command = "list"
		case strings.HasSuffix(arg, ".shk"):
			inputFile = arg
		default:
			if inputFile == "" && !strings.HasPrefix(arg, "-") {
				inputFile = arg
			} else {
				fmt.Fprintf(os.Stderr, "error: unknown option '%s'\n", arg)
				os.Exit(1)
			}
		}
		i++
	}

	switch command {
	case "install":
		pm := pkgmanager.New(verbose)
		err := pm.Install(pkgURL)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(1)
		}
		return
	case "uninstall":
		pm := pkgmanager.New(verbose)
		err := pm.Uninstall(pkgName)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(1)
		}
		return
	case "list":
		pm := pkgmanager.New(verbose)
		err := pm.List()
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(1)
		}
		return
	}

	if inputFile == "" {
		fmt.Fprintln(os.Stderr, "error: no input file specified")
		printUsage()
		os.Exit(1)
	}

	if !strings.HasSuffix(inputFile, ".shk") {
		inputFile = inputFile + ".shk"
	}

	source, err := os.ReadFile(inputFile)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: cannot read file '%s': %v\n", inputFile, err)
		os.Exit(1)
	}

	if verbose {
		fmt.Printf("[shark] Compiling %s...\n", inputFile)
	}

	lex := lexer.New(string(source))
	tokens, err := lex.Tokenize()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Lexer error: %v\n", err)
		os.Exit(1)
	}

	if printTokens {
		fmt.Println("=== Tokens ===")
		for _, tok := range tokens {
			fmt.Println(tok)
		}
		return
	}

	p := parser.New(tokens)
	program, err := p.Parse()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Parse error: %v\n", err)
		os.Exit(1)
	}

	if printAST {
		fmt.Println("=== AST ===")
		printASTNode(program, 0)
		return
	}

	a := analyzer.New()
	errors := a.Analyze(program)
	if len(errors) > 0 {
		for _, e := range errors {
			fmt.Fprintf(os.Stderr, "Warning: %s\n", e)
		}
	}

	gen := codegen.New()
	irCode, err := gen.Generate(program)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Code generation error: %v\n", err)
		os.Exit(1)
	}

	if emitIR {
		irFile := strings.TrimSuffix(inputFile, ".shk") + ".ll"
		if outputFile != "" {
			irFile = outputFile
		}
		err = os.WriteFile(irFile, []byte(irCode), 0644)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: cannot write IR file: %v\n", err)
			os.Exit(1)
		}
		if verbose {
			fmt.Printf("[shark] IR written to %s\n", irFile)
		}
		return
	}

	if outputFile == "" {
		outputFile = "a.out"
	}

	absOutput, err := filepath.Abs(outputFile)
	if err != nil {
		absOutput = outputFile
	}

	lnk, err := linker.New(verbose)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Linker error: %v\n", err)
		os.Exit(1)
	}

	err = lnk.CompileIR(irCode, absOutput)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Build error: %v\n", err)
		os.Exit(1)
	}

	if command == "run" {
		if verbose {
			fmt.Printf("[shark] Running %s...\n", absOutput)
		}

		execCmd := createExecCommand(absOutput)
		execCmd.Stdin = os.Stdin
		execCmd.Stdout = os.Stdout
		execCmd.Stderr = os.Stderr
		err = execCmd.Run()

		os.Remove(absOutput)

		if err != nil {
			if exitErr, ok := err.(*exitError); ok {
				os.Exit(exitErr.code)
			}
			fmt.Fprintf(os.Stderr, "Runtime error: %v\n", err)
			os.Exit(1)
		}
	}
}

func printASTNode(node parser.Node, indent int) {
	prefix := strings.Repeat("  ", indent)

	switch n := node.(type) {
	case *parser.Program:
		fmt.Printf("%sProgram\n", prefix)
		for _, s := range n.Statements {
			printASTNode(s, indent+1)
		}
	case *parser.LetStatement:
		fmt.Printf("%sLet(%s, const=%v)\n", prefix, n.Name, n.IsConst)
		if n.Value != nil {
			printASTNode(n.Value, indent+1)
		}
	case *parser.AssignStatement:
		fmt.Printf("%sAssign(op=%s)\n", prefix, n.Op)
		printASTNode(n.Target, indent+1)
		printASTNode(n.Value, indent+1)
	case *parser.FunctionDecl:
		params := make([]string, len(n.Params))
		for i, p := range n.Params {
			params[i] = p.Name
		}
		fmt.Printf("%sFn(%s, params=[%s])\n", prefix, n.Name, strings.Join(params, ", "))
		for _, s := range n.Body {
			printASTNode(s, indent+1)
		}
	case *parser.ReturnStatement:
		fmt.Printf("%sReturn\n", prefix)
		if n.Value != nil {
			printASTNode(n.Value, indent+1)
		}
	case *parser.IfStatement:
		fmt.Printf("%sIf\n", prefix)
		printASTNode(n.Condition, indent+1)
		for _, s := range n.Body {
			printASTNode(s, indent+1)
		}
	case *parser.WhileStatement:
		fmt.Printf("%sWhile\n", prefix)
		printASTNode(n.Condition, indent+1)
		for _, s := range n.Body {
			printASTNode(s, indent+1)
		}
	case *parser.ForStatement:
		fmt.Printf("%sFor(%s)\n", prefix, n.Variable)
		printASTNode(n.Iterable, indent+1)
		for _, s := range n.Body {
			printASTNode(s, indent+1)
		}
	case *parser.ExpressionStatement:
		fmt.Printf("%sExprStmt\n", prefix)
		printASTNode(n.Expression, indent+1)
	case *parser.BinaryExpr:
		fmt.Printf("%sBinaryExpr(%s)\n", prefix, n.Operator)
		printASTNode(n.Left, indent+1)
		printASTNode(n.Right, indent+1)
	case *parser.UnaryExpr:
		fmt.Printf("%sUnaryExpr(%s)\n", prefix, n.Operator)
		printASTNode(n.Operand, indent+1)
	case *parser.CallExpr:
		fmt.Printf("%sCall\n", prefix)
		printASTNode(n.Callee, indent+1)
		for _, a := range n.Args {
			printASTNode(a, indent+1)
		}
	case *parser.IntLiteral:
		fmt.Printf("%sInt(%d)\n", prefix, n.Value)
	case *parser.FloatLiteral:
		fmt.Printf("%sFloat(%f)\n", prefix, n.Value)
	case *parser.StringLiteral:
		fmt.Printf("%sString(%q)\n", prefix, n.Value)
	case *parser.BoolLiteral:
		fmt.Printf("%sBool(%v)\n", prefix, n.Value)
	case *parser.NilLiteral:
		fmt.Printf("%sNil\n", prefix)
	case *parser.Identifier:
		fmt.Printf("%sIdent(%s)\n", prefix, n.Name)
	case *parser.ArrayLiteral:
		fmt.Printf("%sArray(%d elements)\n", prefix, len(n.Elements))
	case *parser.RangeExpr:
		fmt.Printf("%sRange\n", prefix)
	case *parser.ImportStatement:
		fmt.Printf("%sImport(%s)\n", prefix, n.Path)
	case *parser.StructDecl:
		fmt.Printf("%sStruct(%s)\n", prefix, n.Name)
	case *parser.BreakStatement:
		fmt.Printf("%sBreak\n", prefix)
	case *parser.ContinueStatement:
		fmt.Printf("%sContinue\n", prefix)
	case *parser.IndexExpr:
		fmt.Printf("%sIndex\n", prefix)
	case *parser.MemberExpr:
		fmt.Printf("%sMember(.%s)\n", prefix, n.Member)
	default:
		fmt.Printf("%sUnknown(%T)\n", prefix, node)
	}
}
